# =========================================================
# DATASET 1 PREPROCESSING
# Student Performance Prediction
# =========================================================

# ---------------------------------------------------------
# IMPORT LIBRARIES
# ---------------------------------------------------------

import pandas as pd
import numpy as np
import os

from sklearn.model_selection import train_test_split

# ---------------------------------------------------------
# PROJECT INFORMATION
# ---------------------------------------------------------

print("=" * 80)
print("DATASET 1 PREPROCESSING")
print("1 MILLION ROWS STUDENT PERFORMANCE DATASET")
print("=" * 80)

# ---------------------------------------------------------
# PATH SETUP
# ---------------------------------------------------------

# Current file directory
current_dir = os.path.dirname(os.path.abspath(__file__))

# Project root directory
project_root = os.path.dirname(current_dir)

# Folder paths
data_path = os.path.join(project_root, "data")
output_path = os.path.join(project_root, "outputs")
report_path = os.path.join(project_root, "reports")

# Create folders if not exist
os.makedirs(output_path, exist_ok=True)
os.makedirs(report_path, exist_ok=True)

# ---------------------------------------------------------
# LOAD DATASET
# ---------------------------------------------------------

print("\nLoading dataset...")

# Memory efficient loading
df = pd.read_csv(
    os.path.join(data_path, "student_performance_dataset_1.csv")
)

print("Dataset loaded successfully!")

# ---------------------------------------------------------
# BASIC INFORMATION
# ---------------------------------------------------------

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Columns:")
print(df.columns.tolist())

# ---------------------------------------------------------
# MEMORY OPTIMIZATION
# ---------------------------------------------------------

print("\nOptimizing memory usage...")

# Convert float64 -> float32
float_cols = df.select_dtypes(include=['float64']).columns

for col in float_cols:
    df[col] = df[col].astype('float32')

# Convert int64 -> int32
int_cols = df.select_dtypes(include=['int64']).columns

for col in int_cols:
    df[col] = df[col].astype('int32')

print("Memory optimization completed!")

# ---------------------------------------------------------
# CHECK MISSING VALUES
# ---------------------------------------------------------

print("\nMissing Values:")

missing_values = df.isnull().sum()

print(missing_values)

# ---------------------------------------------------------
# CHECK DUPLICATES
# ---------------------------------------------------------

duplicates = df.duplicated().sum()

print("\nDuplicate Rows:")
print(duplicates)

# Remove duplicates if exist
if duplicates > 0:

    print("\nRemoving duplicates...")

    df = df.drop_duplicates()

    print("Duplicates removed!")

# ---------------------------------------------------------
# TARGET CREATION
# ---------------------------------------------------------

print("\nCreating target column...")

# ---------------------------------------------------------
# TARGET:
# 0 = Low
# 1 = Medium
# 2 = High
# ---------------------------------------------------------

def create_target(grade):

    # Low Performance
    if grade in ['D', 'F']:
        return 0

    # Medium Performance
    elif grade in ['B', 'C']:
        return 1

    # High Performance
    else:
        return 2

# Apply target mapping
df['target'] = df['grade'].apply(create_target)

print("\nTarget Distribution:")
print(df['target'].value_counts())

# ---------------------------------------------------------
# FEATURE ENGINEERING
# ---------------------------------------------------------

print("\nCreating engineered features...")

# Student engagement score
df['engagement_score'] = (
    df['attendance_percentage'] *
    df['class_participation']
)

# Study effectiveness
df['study_effectiveness'] = (
    df['weekly_self_study_hours'] *
    df['attendance_percentage']
)

print("Feature engineering completed!")

# ---------------------------------------------------------
# REMOVE DATA LEAKAGE
# ---------------------------------------------------------

print("\nRemoving leakage features...")

# ---------------------------------------------------------
# REMOVE:
# student_id  -> unique identifier
# total_score -> directly determines grade
# grade       -> original target source
# target      -> label column
# ---------------------------------------------------------

X = df.drop([
    'student_id',
    'total_score',
    'grade',
    'target'
], axis=1)

# Target variable
y = df['target']

print("\nFinal Features Used:")
print(X.columns.tolist())

# ---------------------------------------------------------
# TRAIN TEST SPLIT
# ---------------------------------------------------------

print("\nCreating train-test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining Shape:")
print(X_train.shape)

print("\nTesting Shape:")
print(X_test.shape)

# ---------------------------------------------------------
# SAVE PROCESSED FILES
# ---------------------------------------------------------

print("\nSaving processed datasets...")

# Features
X_train.to_csv(
    os.path.join(output_path, "X_train_dataset1.csv"),
    index=False
)

X_test.to_csv(
    os.path.join(output_path, "X_test_dataset1.csv"),
    index=False
)

# Labels
y_train.to_csv(
    os.path.join(output_path, "y_train_dataset1.csv"),
    index=False
)

y_test.to_csv(
    os.path.join(output_path, "y_test_dataset1.csv"),
    index=False
)

print("Processed files saved successfully!")

# ---------------------------------------------------------
# SAVE PREPROCESSING REPORT
# ---------------------------------------------------------

report_file = os.path.join(
    report_path,
    "dataset1_preprocessing_report.txt"
)

with open(report_file, "w", encoding="utf-8") as f:

    f.write("DATASET 1 PREPROCESSING REPORT\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Dataset Shape: {df.shape}\n\n")

    f.write("Features Used:\n")
    f.write(str(X.columns.tolist()))

    f.write("\n\n")

    f.write("Target Distribution:\n")
    f.write(str(df['target'].value_counts()))

    f.write("\n\n")

    f.write("Missing Values:\n")
    f.write(str(missing_values))

print("\nReport saved successfully!")
print(report_file)

# ---------------------------------------------------------
# COMPLETED
# ---------------------------------------------------------

print("\nPREPROCESSING COMPLETED SUCCESSFULLY!")
print("=" * 80)