import pandas as pd
import os

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

print("=" * 80)
print("RANDOM FOREST MODEL - DATASET 1")
print("=" * 80)

# ------------------------------------------------
# PATH SETUP
# ------------------------------------------------
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

output_path = os.path.join(project_root, "outputs")
report_path = os.path.join(project_root, "reports")

os.makedirs(report_path, exist_ok=True)

# ------------------------------------------------
# LOAD PROCESSED DATA
# ------------------------------------------------
print("\nLoading processed dataset...")

X_train = pd.read_csv(
    os.path.join(output_path, "X_train_dataset1.csv")
)

X_test = pd.read_csv(
    os.path.join(output_path, "X_test_dataset1.csv")
)

y_train = pd.read_csv(
    os.path.join(output_path, "y_train_dataset1.csv")
).squeeze()

y_test = pd.read_csv(
    os.path.join(output_path, "y_test_dataset1.csv")
).squeeze()

print("Data loaded successfully!")

print("\nTraining Shape:")
print(X_train.shape)

print("\nTesting Shape:")
print(X_test.shape)

print("\nFeatures Used:")
print(X_train.columns.tolist())

# ------------------------------------------------
# MODEL CREATION
# ------------------------------------------------
print("\nCreating Random Forest model...")

model = RandomForestClassifier(
    n_estimators=50,
    max_depth=15,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    n_jobs=-1
)

# ------------------------------------------------
# TRAIN MODEL
# ------------------------------------------------
print("\nTraining model...")

model.fit(X_train, y_train)

print("Training completed!")

# ------------------------------------------------
# PREDICTION
# ------------------------------------------------
print("\nMaking predictions...")

y_pred = model.predict(X_test)

# ------------------------------------------------
# EVALUATION
# ------------------------------------------------
print("\nEvaluating model...")

accuracy = accuracy_score(y_test, y_pred)

report = classification_report(
    y_test,
    y_pred
)

matrix = confusion_matrix(
    y_test,
    y_pred
)

# ------------------------------------------------
# RESULTS
# ------------------------------------------------
print("\n" + "=" * 80)
print("RANDOM FOREST RESULTS")
print("=" * 80)

print("\nAccuracy:")
print(round(accuracy, 4))

print("\nClassification Report:")
print(report)

print("\nConfusion Matrix:")
print(matrix)

# ------------------------------------------------
# FEATURE IMPORTANCE
# ------------------------------------------------
importance_df = pd.DataFrame({
    'Feature': X_train.columns,
    'Importance': model.feature_importances_
})

importance_df = importance_df.sort_values(
    by='Importance',
    ascending=False
)

print("\nFeature Importance:")
print(importance_df)

# ------------------------------------------------
# SAVE RESULTS
# ------------------------------------------------
result_file = os.path.join(
    report_path,
    "random_forest_dataset1_results.txt"
)

with open(result_file, "w", encoding="utf-8") as f:

    f.write("RANDOM FOREST RESULTS\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Accuracy: {accuracy}\n\n")

    f.write("Classification Report:\n")
    f.write(report)

    f.write("\nConfusion Matrix:\n")
    f.write(str(matrix))

    f.write("\n\nFeature Importance:\n")
    f.write(str(importance_df))

print("\nResults saved successfully!")
print(result_file)

print("\nMODEL COMPLETED SUCCESSFULLY!")
print("=" * 80)