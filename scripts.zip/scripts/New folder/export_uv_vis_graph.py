from pathlib import Path
import xml.etree.ElementTree as ET

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


XML_PATH = Path(r"C:\Users\Usman\Desktop\1 Figure_xml_20260721_e17d2a.xml")
OUTPUT_DIR = Path(r"D:\nndl2024\Usman_YLU_final_project\outputs")
PNG_PATH = OUTPUT_DIR / "Figure1_UV_Vis_Spectra_HD_600dpi.png"
SVG_PATH = OUTPUT_DIR / "Figure1_UV_Vis_Spectra_Vector.svg"

COLORS = {
    "blue": "#1769AA",
    "red": "#D1495B",
    "green": "#2E8B57",
}
LINESTYLES = {
    "solid": "-",
    "dashed": "--",
    "dotted": ":",
}


def read_graph():
    root = ET.parse(XML_PATH).getroot()
    graph = root.find("./project/folder/graph")
    if graph is None:
        raise ValueError("The XML does not contain an Origin-style graph element.")

    datasets = []
    for dataset in graph.findall("./data/dataset"):
        points = [
            (float(point.attrib["x"]), float(point.attrib["y"]))
            for point in dataset.findall("./point")
        ]
        datasets.append(
            {
                "name": dataset.attrib["name"],
                "color": COLORS.get(dataset.attrib.get("color", ""), "#333333"),
                "linestyle": LINESTYLES.get(
                    dataset.attrib.get("lineStyle", "solid"), "-"
                ),
                "linewidth": float(dataset.attrib.get("lineWidth", "1.5")) + 0.4,
                "points": points,
            }
        )

    return {
        "title": graph.findtext("./title", default="UV–Vis Absorption Spectra"),
        "x_label": graph.findtext("./xAxis/label", default="Wavelength (nm)"),
        "x_from": float(graph.findtext("./xAxis/scale/from", default="300")),
        "x_to": float(graph.findtext("./xAxis/scale/to", default="600")),
        "x_increment": float(
            graph.findtext("./xAxis/scale/increment", default="50")
        ),
        "y_label": graph.findtext("./yAxis/label", default="Absorbance (a.u.)"),
        "y_from": float(graph.findtext("./yAxis/scale/from", default="0")),
        "y_to": float(graph.findtext("./yAxis/scale/to", default="1.2")),
        "y_increment": float(
            graph.findtext("./yAxis/scale/increment", default="0.2")
        ),
        "datasets": datasets,
    }


def tick_values(start, stop, increment):
    count = round((stop - start) / increment)
    return [start + index * increment for index in range(count + 1)]


def render():
    graph = read_graph()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 12,
            "axes.titlesize": 16,
            "axes.labelsize": 13,
            "legend.fontsize": 11,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "svg.fonttype": "none",
        }
    )

    figure, axis = plt.subplots(figsize=(10, 6), constrained_layout=True)
    figure.patch.set_facecolor("white")
    axis.set_facecolor("white")

    for dataset in graph["datasets"]:
        x_values = [point[0] for point in dataset["points"]]
        y_values = [point[1] for point in dataset["points"]]
        axis.plot(
            x_values,
            y_values,
            label=dataset["name"],
            color=dataset["color"],
            linestyle=dataset["linestyle"],
            linewidth=dataset["linewidth"],
            solid_capstyle="round",
            dash_capstyle="round",
            zorder=3,
        )

    axis.set_xlim(graph["x_from"], graph["x_to"])
    axis.set_ylim(graph["y_from"], graph["y_to"])
    axis.set_xticks(
        tick_values(graph["x_from"], graph["x_to"], graph["x_increment"])
    )
    axis.set_yticks(
        tick_values(graph["y_from"], graph["y_to"], graph["y_increment"])
    )
    axis.set_xlabel(graph["x_label"], labelpad=10)
    axis.set_ylabel(graph["y_label"], labelpad=10)
    axis.set_title(graph["title"], pad=18, weight="semibold")

    axis.grid(True, color="#D9DEE5", linewidth=0.7, alpha=0.85, zorder=0)
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)
    axis.spines["left"].set_color("#4B5563")
    axis.spines["bottom"].set_color("#4B5563")
    axis.tick_params(colors="#374151", direction="out", length=4, width=0.8)

    dataset_by_name = {dataset["name"]: dataset for dataset in graph["datasets"]}
    annotations = [
        ("ZnO NPs", (370, 1.00), (405, 1.08), "λmax = 370 nm"),
        ("Bulk ZnO", (385, 0.60), (425, 0.69), "λmax = 385 nm"),
    ]
    for name, peak, text_position, label in annotations:
        color = dataset_by_name[name]["color"]
        axis.scatter(
            [peak[0]],
            [peak[1]],
            s=42,
            facecolor="white",
            edgecolor=color,
            linewidth=1.8,
            zorder=5,
        )
        axis.annotate(
            label,
            xy=peak,
            xytext=text_position,
            color="#1F2937",
            fontsize=10.5,
            ha="left",
            va="center",
            arrowprops={
                "arrowstyle": "->",
                "color": color,
                "linewidth": 1.2,
                "shrinkA": 4,
                "shrinkB": 5,
            },
            zorder=6,
        )

    legend = axis.legend(
        loc="upper right",
        frameon=True,
        facecolor="white",
        edgecolor="#CBD5E1",
        framealpha=0.96,
        borderpad=0.8,
        handlelength=3.2,
    )
    for text in legend.get_texts():
        text.set_color("#1F2937")

    figure.savefig(
        PNG_PATH,
        dpi=600,
        facecolor="white",
        bbox_inches="tight",
        metadata={
            "Title": graph["title"],
            "Description": "Generated from the supplied XML datasets.",
        },
    )
    figure.savefig(
        SVG_PATH,
        format="svg",
        facecolor="white",
        bbox_inches="tight",
        metadata={
            "Title": graph["title"],
            "Description": "Generated from the supplied XML datasets.",
        },
    )
    plt.close(figure)

    print(PNG_PATH)
    print(SVG_PATH)


if __name__ == "__main__":
    render()
