"""
Five-fold cross-validation for Dataset 3.

The script evaluates the five final Dataset 3 models with stratified folds and
saves mean accuracy and standard deviation for journal-ready reporting.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

try:
    from xgboost import XGBClassifier
except ImportError as exc:  # pragma: no cover - only triggered when xgboost is absent.
    raise ImportError("xgboost is required for the Dataset 3 cross-validation pipeline.") from exc


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = PROJECT_ROOT / "data" / "StudentPerformanceFactors_dataset3_final.csv"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"

TARGET_COLUMN = "Performance_Class"
LEAKAGE_COLUMNS = [TARGET_COLUMN, "Exam_Score", "performance_trend", "score_ratio"]
RANDOM_STATE = 42


def ensure_directories() -> None:
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)


def load_dataset3() -> tuple[pd.DataFrame, pd.Series]:
    data = pd.read_csv(DATASET_PATH)
    x = data.drop(columns=LEAKAGE_COLUMNS, errors="ignore")
    y = data[TARGET_COLUMN]
    return x, y


def build_models() -> dict[str, object]:
    return {
        "Logistic Regression": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "model",
                    LogisticRegression(
                        max_iter=5000,
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "Decision Tree": DecisionTreeClassifier(
            criterion="gini",
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            criterion="gini",
            max_depth=12,
            min_samples_split=5,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
        "SVM": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "model",
                    SVC(
                        C=10,
                        kernel="rbf",
                        gamma="scale",
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "XGBoost": XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=RANDOM_STATE,
            eval_metric="mlogloss",
        ),
    }


def run_cross_validation(x: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    rows = []

    for model_name, model in build_models().items():
        scores = cross_val_score(model, x, y, cv=cv, scoring="accuracy", n_jobs=-1)
        rows.append(
            {
                "Model": model_name,
                "Mean Accuracy": scores.mean(),
                "Standard Deviation": scores.std(),
            }
        )

    return pd.DataFrame(rows).sort_values("Mean Accuracy", ascending=False)


def main() -> None:
    ensure_directories()
    x, y = load_dataset3()
    results = run_cross_validation(x, y)

    output_path = OUTPUTS_DIR / "dataset3_5fold_cross_validation_results.csv"
    results.to_csv(output_path, index=False)

    print("\nDataset 3: Five-Fold Cross-Validation Results")
    print("=============================================")
    print(results.round(4).to_string(index=False))
    print("\nCross-validation results saved in:", output_path)


if __name__ == "__main__":
    main()
