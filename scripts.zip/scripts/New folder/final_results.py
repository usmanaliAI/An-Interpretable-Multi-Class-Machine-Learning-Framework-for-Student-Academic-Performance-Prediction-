"""
Final research result tables for all datasets.

This script consolidates model performance into publication-ready CSV tables:
- Dataset 1: model accuracy
- Dataset 2: model accuracy
- Dataset 3: accuracy, precision, recall, and F1-score
"""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS_DIR = PROJECT_ROOT / "reports"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"
TABLES_DIR = PROJECT_ROOT / "tables"


DATASET1_REPORTS = {
    "Decision Tree": REPORTS_DIR / "dataset1" / "decision_tree_dataset1_results.txt",
    "Random Forest": REPORTS_DIR / "dataset1" / "random_forest_dataset1_results.txt",
}

DATASET2_REPORTS = {
    "Decision Tree": REPORTS_DIR / "dataset2" / "dataset2_decision_tree_results.txt",
    "Random Forest": REPORTS_DIR / "dataset2" / "dataset2_random_forest_results.txt",
}

DATASET3_PREDICTIONS = {
    "Decision Tree": OUTPUTS_DIR / "dataset3" / "dataset3_decision_tree_predictions.csv",
    "Random Forest": OUTPUTS_DIR / "dataset3" / "dataset3_random_forest_predictions.csv",
    "Logistic Regression": OUTPUTS_DIR / "dataset3" / "dataset3_logistic_regression_predictions.csv",
    "SVM": OUTPUTS_DIR / "dataset3" / "dataset3_svm_predictions.csv",
    "XGBoost": OUTPUTS_DIR / "dataset3" / "dataset3_xgboost_predictions.csv",
}


def ensure_directories() -> None:
    TABLES_DIR.mkdir(parents=True, exist_ok=True)


def extract_accuracy(report_path: Path) -> float:
    text = report_path.read_text(encoding="utf-8")
    match = re.search(r"Accuracy:\s*([0-9]*\.?[0-9]+)", text)
    if not match:
        raise ValueError(f"Accuracy value was not found in {report_path}")
    return float(match.group(1))


def build_accuracy_table(report_map: dict[str, Path]) -> pd.DataFrame:
    rows = [
        {
            "Model": model_name,
            "Accuracy": extract_accuracy(report_path),
        }
        for model_name, report_path in report_map.items()
    ]
    return pd.DataFrame(rows).sort_values("Accuracy", ascending=False)


def build_dataset3_table() -> pd.DataFrame:
    rows = []

    for model_name, prediction_path in DATASET3_PREDICTIONS.items():
        predictions = pd.read_csv(prediction_path)
        y_true = predictions["Actual"]
        y_pred = predictions["Predicted"]

        rows.append(
            {
                "Model": model_name,
                "Accuracy": accuracy_score(y_true, y_pred),
                "Precision": precision_score(y_true, y_pred, average="weighted", zero_division=0),
                "Recall": recall_score(y_true, y_pred, average="weighted", zero_division=0),
                "F1-score": f1_score(y_true, y_pred, average="weighted", zero_division=0),
            }
        )

    return pd.DataFrame(rows).sort_values("Accuracy", ascending=False)


def save_table(table: pd.DataFrame, filename: str) -> Path:
    output_path = TABLES_DIR / filename
    table.to_csv(output_path, index=False)
    return output_path


def print_table(title: str, table: pd.DataFrame) -> None:
    print("\n" + title)
    print("=" * len(title))
    formatted = table.copy()
    numeric_columns = formatted.select_dtypes(include="number").columns
    formatted[numeric_columns] = formatted[numeric_columns].round(4)
    print(formatted.to_string(index=False))


def main() -> None:
    ensure_directories()

    dataset1_table = build_accuracy_table(DATASET1_REPORTS)
    dataset2_table = build_accuracy_table(DATASET2_REPORTS)
    dataset3_table = build_dataset3_table()

    save_table(dataset1_table, "dataset1_final_model_comparison.csv")
    save_table(dataset2_table, "dataset2_final_model_comparison.csv")
    save_table(dataset3_table, "dataset3_final_model_comparison.csv")

    print_table("Dataset 1: Model Accuracy Comparison", dataset1_table)
    print_table("Dataset 2: Model Accuracy Comparison", dataset2_table)
    print_table("Dataset 3: Final Model Performance Comparison", dataset3_table)

    print("\nFinal tables saved in:", TABLES_DIR)


if __name__ == "__main__":
    main()
