"""
Publication-quality figures for Dataset 3.

Generated outputs:
- Dataset 3 model comparison bar chart
- Confusion matrix for the best model
- Feature importance plot for the best model
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = PROJECT_ROOT / "data" / "StudentPerformanceFactors_dataset3_final.csv"
TABLES_DIR = PROJECT_ROOT / "tables"
FIGURES_DIR = PROJECT_ROOT / "figures"

TARGET_COLUMN = "Performance_Class"
LEAKAGE_COLUMNS = [TARGET_COLUMN, "Exam_Score", "performance_trend", "score_ratio"]
RANDOM_STATE = 42


def ensure_directories() -> None:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)


def load_dataset3() -> tuple[pd.DataFrame, pd.Series]:
    data = pd.read_csv(DATASET_PATH)
    x = data.drop(columns=LEAKAGE_COLUMNS, errors="ignore")
    y = data[TARGET_COLUMN]
    return x, y


def train_best_model(
    x: pd.DataFrame,
    y: pd.Series,
) -> tuple[RandomForestClassifier, pd.DataFrame, pd.Series, pd.Series]:
    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y,
    )
    model = RandomForestClassifier(
        n_estimators=300,
        criterion="gini",
        max_depth=12,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    predictions = pd.Series(model.predict(x_test), index=y_test.index, name="Predicted")
    return model, x_test, y_test, predictions


def load_or_create_model_comparison() -> pd.DataFrame:
    table_path = TABLES_DIR / "dataset3_final_model_comparison.csv"
    if table_path.exists():
        return pd.read_csv(table_path)

    prediction_files = {
        "Decision Tree": PROJECT_ROOT / "outputs" / "dataset3" / "dataset3_decision_tree_predictions.csv",
        "Random Forest": PROJECT_ROOT / "outputs" / "dataset3" / "dataset3_random_forest_predictions.csv",
        "Logistic Regression": PROJECT_ROOT / "outputs" / "dataset3" / "dataset3_logistic_regression_predictions.csv",
        "SVM": PROJECT_ROOT / "outputs" / "dataset3" / "dataset3_svm_predictions.csv",
        "XGBoost": PROJECT_ROOT / "outputs" / "dataset3" / "dataset3_xgboost_predictions.csv",
    }

    rows = []
    for model_name, prediction_path in prediction_files.items():
        predictions = pd.read_csv(prediction_path)
        accuracy = (predictions["Actual"] == predictions["Predicted"]).mean()
        rows.append({"Model": model_name, "Accuracy": accuracy})

    comparison = pd.DataFrame(rows).sort_values("Accuracy", ascending=False)
    comparison.to_csv(table_path, index=False)
    return comparison


def plot_model_comparison(comparison: pd.DataFrame) -> Path:
    figure_path = FIGURES_DIR / "dataset3_model_comparison_publication.png"
    sns.set_theme(style="whitegrid", font_scale=1.1)

    plt.figure(figsize=(9, 5.5))
    axis = sns.barplot(
        data=comparison,
        x="Accuracy",
        y="Model",
        color="#457B9D",
    )
    axis.set_title("Dataset 3 Model Accuracy Comparison", weight="bold")
    axis.set_xlabel("Accuracy")
    axis.set_ylabel("Model")
    axis.set_xlim(0, 1)

    for container in axis.containers:
        axis.bar_label(container, fmt="%.3f", padding=4)

    sns.despine(left=True, bottom=True)
    plt.tight_layout()
    plt.savefig(figure_path, dpi=300, bbox_inches="tight")
    plt.close()
    return figure_path


def plot_confusion_matrix(y_test: pd.Series, predictions: pd.Series) -> Path:
    figure_path = FIGURES_DIR / "dataset3_random_forest_confusion_matrix_publication.png"
    labels = sorted(y_test.unique())
    matrix = confusion_matrix(y_test, predictions, labels=labels)

    plt.figure(figsize=(7, 6))
    axis = sns.heatmap(
        matrix,
        annot=True,
        fmt="d",
        cmap="YlGnBu",
        xticklabels=labels,
        yticklabels=labels,
        cbar_kws={"label": "Number of students"},
    )
    axis.set_title("Random Forest Confusion Matrix - Dataset 3", weight="bold")
    axis.set_xlabel("Predicted Class")
    axis.set_ylabel("Actual Class")
    plt.tight_layout()
    plt.savefig(figure_path, dpi=300, bbox_inches="tight")
    plt.close()
    return figure_path


def plot_feature_importance(model: RandomForestClassifier, feature_names: pd.Index) -> Path:
    figure_path = FIGURES_DIR / "dataset3_random_forest_feature_importance_plot_publication.png"
    importance = pd.DataFrame(
        {
            "Feature": feature_names,
            "Importance": model.feature_importances_,
        }
    ).sort_values("Importance", ascending=False)

    plt.figure(figsize=(10, 7))
    axis = sns.barplot(
        data=importance.head(15),
        x="Importance",
        y="Feature",
        color="#E76F51",
    )
    axis.set_title("Top 15 Features - Random Forest", weight="bold")
    axis.set_xlabel("Importance Score")
    axis.set_ylabel("Feature")
    sns.despine(left=True, bottom=True)
    plt.tight_layout()
    plt.savefig(figure_path, dpi=300, bbox_inches="tight")
    plt.close()
    return figure_path


def main() -> None:
    ensure_directories()
    x, y = load_dataset3()
    model, _, y_test, predictions = train_best_model(x, y)
    comparison = load_or_create_model_comparison()

    comparison_path = plot_model_comparison(comparison)
    confusion_path = plot_confusion_matrix(y_test, predictions)
    importance_path = plot_feature_importance(model, x.columns)

    print("\nPublication-quality figures saved:")
    print("Model comparison:", comparison_path)
    print("Confusion matrix:", confusion_path)
    print("Feature importance:", importance_path)


if __name__ == "__main__":
    main()
