import csv
import datetime as dt
import os
import re
import struct
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports" / "dataset3" / "student_performance_dataset3_supervisor_report.docx"


def read_csv_rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader), reader.fieldnames


def png_size(path):
    with open(path, "rb") as f:
        sig = f.read(24)
    if sig[:8] != b"\x89PNG\r\n\x1a\n":
        return 1000, 700
    width, height = struct.unpack(">II", sig[16:24])
    return width, height


def parse_model_report(path):
    text = Path(path).read_text(encoding="utf-8")
    acc = float(re.search(r"Accuracy:\s*([0-9.]+)", text).group(1))
    macro = re.search(r"macro avg\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)", text)
    weighted = re.search(r"weighted avg\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)", text)
    return {
        "accuracy": acc,
        "macro_precision": float(macro.group(1)),
        "macro_recall": float(macro.group(2)),
        "macro_f1": float(macro.group(3)),
        "weighted_precision": float(weighted.group(1)),
        "weighted_recall": float(weighted.group(2)),
        "weighted_f1": float(weighted.group(3)),
        "text": text,
    }


def paragraph(text="", style=None, bold=False, italic=False, align=None):
    props = []
    if style:
        props.append(f'<w:pStyle w:val="{style}"/>')
    if align:
        props.append(f'<w:jc w:val="{align}"/>')
    ppr = f"<w:pPr>{''.join(props)}</w:pPr>" if props else ""
    rprops = []
    if bold:
        rprops.append("<w:b/>")
    if italic:
        rprops.append("<w:i/>")
    rpr = f"<w:rPr>{''.join(rprops)}</w:rPr>" if rprops else ""
    return f"<w:p>{ppr}<w:r>{rpr}<w:t xml:space=\"preserve\">{escape(str(text))}</w:t></w:r></w:p>"


def heading(text, level=1):
    return paragraph(text, style=f"Heading{level}")


def page_break():
    return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'


def table(rows, widths=None):
    if not rows:
        return ""
    cols = len(rows[0])
    if widths is None:
        widths = [str(int(9000 / cols))] * cols
    xml = ['<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/><w:tblLook w:firstRow="1" w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>']
    for w in widths:
        xml.append(f'<w:gridCol w:w="{w}"/>')
    xml.append("</w:tblGrid>")
    for ridx, row in enumerate(rows):
        xml.append("<w:tr>")
        for cell in row:
            shade = '<w:shd w:fill="EAF2F1"/>' if ridx == 0 else ""
            xml.append(f'<w:tc><w:tcPr><w:tcW w:w="{widths[min(len(widths)-1, row.index(cell) if cell in row else 0)]}" w:type="dxa"/>{shade}</w:tcPr>')
            xml.append(paragraph(cell, bold=(ridx == 0)))
            xml.append("</w:tc>")
        xml.append("</w:tr>")
    xml.append("</w:tbl>")
    return "".join(xml)


class Doc:
    def __init__(self):
        self.body = []
        self.rels = []
        self.media = []
        self.rid = 1
        self.figure_no = 0
        self.table_no = 0
        self.figure_list = []
        self.table_list = []

    def add(self, xml):
        self.body.append(xml)

    def p(self, text="", **kwargs):
        self.add(paragraph(text, **kwargs))

    def h(self, text, level=1):
        self.add(heading(text, level))

    def page_break(self):
        self.add(page_break())

    def add_table(self, title, rows, note=None):
        self.table_no += 1
        caption = f"Table {self.table_no}. {title}"
        self.table_list.append(caption)
        self.p(caption, style="Caption", bold=True)
        self.add(table(rows))
        if note:
            self.p(note, style="Caption", italic=True)

    def add_image(self, path, caption, explanation, width_in=5.9):
        path = Path(path)
        self.figure_no += 1
        fig_caption = f"Figure {self.figure_no}. {caption}"
        self.figure_list.append(fig_caption)
        rid = f"rId{self.rid}"
        self.rid += 1
        ext = path.suffix.lower().lstrip(".")
        media_name = f"image{self.figure_no}.{ext}"
        self.rels.append((rid, f"media/{media_name}"))
        self.media.append((media_name, path))
        px_w, px_h = png_size(path)
        width_emu = int(width_in * 914400)
        height_emu = int(width_emu * px_h / px_w)
        pic_id = self.figure_no
        self.add(f'''
<w:p>
  <w:pPr><w:jc w:val="center"/></w:pPr>
  <w:r>
    <w:drawing>
      <wp:inline distT="0" distB="0" distL="0" distR="0" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">
        <wp:extent cx="{width_emu}" cy="{height_emu}"/>
        <wp:docPr id="{pic_id}" name="Figure {pic_id}"/>
        <wp:cNvGraphicFramePr/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr>
                <pic:cNvPr id="{pic_id}" name="{escape(path.name)}"/>
                <pic:cNvPicPr/>
              </pic:nvPicPr>
              <pic:blipFill>
                <a:blip r:embed="{rid}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                <a:stretch><a:fillRect/></a:stretch>
              </pic:blipFill>
              <pic:spPr>
                <a:xfrm><a:off x="0" y="0"/><a:ext cx="{width_emu}" cy="{height_emu}"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
              </pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>''')
        self.p(fig_caption, style="Caption", bold=True)
        self.p(explanation)


def pct(x):
    return f"{x * 100:.2f}%"


raw_rows, raw_cols = read_csv_rows(ROOT / "data" / "StudentPerformanceFactors.csv")
final_rows, final_cols = read_csv_rows(ROOT / "data" / "StudentPerformanceFactors_dataset3_final.csv")
target_counts = {}
for row in final_rows:
    target_counts[row["Performance_Class"]] = target_counts.get(row["Performance_Class"], 0) + 1

model_reports = {
    "Decision Tree": parse_model_report(ROOT / "reports" / "dataset3" / "dataset3_decision_tree_results.txt"),
    "Random Forest": parse_model_report(ROOT / "reports" / "dataset3" / "dataset3_random_forest_results.txt"),
    "Logistic Regression": parse_model_report(ROOT / "reports" / "dataset3" / "dataset3_logistic_regression_results.txt"),
    "SVM": parse_model_report(ROOT / "reports" / "dataset3" / "models" / "dataset3_svm_results.txt"),
    "XGBoost": parse_model_report(ROOT / "reports" / "dataset3" / "dataset3_xgboost_results.txt"),
}

original_features = raw_cols
engineered_features = [
    ("study_efficiency", "Hours_Studied / Sleep_Hours", "Measures study effort relative to sleep duration.", "Expected to capture whether long study time is supported by adequate rest."),
    ("attendance_score", "Attendance / 100", "Normalizes attendance as a proportional score.", "Expected to make attendance easier for models to combine with other predictors."),
    ("performance_trend", "Exam_Score - Previous_Scores", "Measures change from previous score to exam score.", "Useful descriptively, but excluded from training because it uses the outcome score."),
    ("sleep_quality", "Sleep_Hours / 8", "Measures sleep duration relative to an 8-hour reference.", "Expected to represent sleep adequacy in a compact numeric form."),
    ("score_ratio", "Exam_Score / Previous_Scores", "Measures exam score relative to previous scores.", "Useful descriptively, but excluded from training because it uses the outcome score."),
    ("overall_productivity", "Hours_Studied * attendance_score", "Combines study time and attendance into one productivity feature.", "Expected to improve prediction by modelling study effort and attendance jointly."),
]

training_features = [
    "Hours_Studied", "Attendance", "Parental_Involvement", "Access_to_Resources",
    "Extracurricular_Activities", "Sleep_Hours", "Previous_Scores", "Motivation_Level",
    "Internet_Access", "Tutoring_Sessions", "Family_Income", "Teacher_Quality",
    "School_Type", "Peer_Influence", "Physical_Activity", "Learning_Disabilities",
    "Parental_Education_Level", "Distance_from_Home", "Gender", "study_efficiency",
    "attendance_score", "sleep_quality", "overall_productivity",
]

figs = {
    "workflow": ROOT / "figures" / "dataset3" / "diagrams" / "dataset3_complete_workflow_diagram.png",
    "fe_framework": ROOT / "figures" / "dataset3" / "diagrams" / "dataset3_feature_engineering_framework.png",
    "model_framework": ROOT / "figures" / "dataset3" / "diagrams" / "dataset3_model_development_framework.png",
    "missing": ROOT / "figures" / "dataset3" / "preprocessing" / "dataset3_missing_values_heatmap.png",
    "hours": ROOT / "figures" / "dataset3" / "preprocessing" / "Hours_Studied_distribution.png",
    "attendance": ROOT / "figures" / "dataset3" / "preprocessing" / "Attendance_distribution.png",
    "previous": ROOT / "figures" / "dataset3" / "preprocessing" / "Previous_Scores_distribution.png",
    "sleep": ROOT / "figures" / "dataset3" / "preprocessing" / "Sleep_Hours_distribution.png",
    "exam": ROOT / "figures" / "dataset3" / "preprocessing" / "Exam_Score_distribution.png",
    "pre_corr": ROOT / "figures" / "dataset3" / "preprocessing" / "dataset3_correlation_heatmap.png",
    "target": ROOT / "figures" / "dataset3" / "feature_engineering" / "dataset3_target_distribution.png",
    "perf_class": ROOT / "figures" / "dataset3" / "feature_engineering" / "performance_class_distribution.png",
    "post_corr": ROOT / "figures" / "dataset3" / "feature_engineering" / "dataset3_feature_correlation_heatmap.png",
    "post_corr2": ROOT / "figures" / "dataset3" / "feature_engineering" / "dataset3_correlation_after_features.png",
}

model_figs = {
    "Decision Tree": {
        "accuracy": ROOT / "figures" / "dataset3" / "models" / "dataset3_decision_tree_accuracy.png",
        "confusion": ROOT / "figures" / "dataset3" / "models" / "dataset3_decision_tree_confusion_matrix.png",
        "importance": ROOT / "figures" / "dataset3" / "models" / "dataset3_decision_tree_feature_importance.png",
    },
    "Random Forest": {
        "accuracy": ROOT / "figures" / "dataset3" / "models" / "dataset3_random_forest_accuracy.png",
        "confusion": ROOT / "figures" / "dataset3" / "models" / "dataset3_random_forest_confusion_matrix.png",
        "importance": ROOT / "figures" / "dataset3" / "models" / "dataset3_random_forest_feature_importance.png",
    },
    "Logistic Regression": {
        "accuracy": ROOT / "figures" / "dataset3" / "models" / "dataset3_logistic_regression_accuracy.png",
        "confusion": ROOT / "figures" / "dataset3" / "models" / "dataset3_logistic_regression_confusion_matrix.png",
        "importance": ROOT / "figures" / "dataset3" / "models" / "dataset3_logistic_regression_feature_importance.png",
    },
    "SVM": {
        "accuracy": ROOT / "figures" / "dataset3" / "models" / "svm" / "dataset3_svm_accuracy.png",
        "confusion": ROOT / "figures" / "dataset3" / "models" / "svm" / "dataset3_svm_confusion_matrix.png",
    },
    "XGBoost": {
        "accuracy": ROOT / "figures" / "dataset3" / "models" / "dataset3_xgboost_accuracy.png",
        "confusion": ROOT / "figures" / "dataset3" / "models" / "dataset3_xgboost_confusion_matrix.png",
        "importance": ROOT / "figures" / "dataset3" / "models" / "dataset3_xgboost_feature_importance.png",
    },
}

doc = Doc()

doc.p("Student Performance Factors Dataset 3", style="Title", align="center")
doc.p("Machine Learning Research Progress Report", style="Subtitle", align="center")
doc.p("Dataset of interest: StudentPerformanceFactors_dataset3_final.csv", align="center")
doc.p("Prepared for Master's supervisor review", align="center")
doc.p(f"Generated: {dt.date.today().isoformat()}", align="center")
doc.page_break()

sections = [
    "1. Introduction",
    "2. Project Analysis and Dataset 3 Evidence Boundary",
    "3. Dataset Investigation",
    "4. Original Features",
    "5. Data Cleaning and Preprocessing",
    "6. Feature Engineering and Research Innovation",
    "7. Target Variable Construction",
    "8. Feature Selection and Data Leakage Control",
    "9. Experimental Design",
    "10. Machine Learning Model Development",
    "11. Results and Performance Analysis",
    "12. Figures and Visualization",
    "13. Discussion",
    "14. Conclusion",
]
doc.h("Table of Contents", 1)
for s in sections:
    doc.p(s)
doc.page_break()

doc.h("List of Figures", 1)
doc.add("__FIGURE_LIST_PLACEHOLDER__")
doc.page_break()

doc.h("List of Tables", 1)
doc.add("__TABLE_LIST_PLACEHOLDER__")
doc.page_break()

doc.h("1. Introduction", 1)
doc.p("This report documents the Dataset 3 machine learning workflow for predicting student performance classes from the Student Performance Factors dataset. The analysis is based exclusively on StudentPerformanceFactors_dataset3_final.csv and the associated Dataset 3 source code, reports, tables, prediction outputs, and figures generated by the project.")
doc.p("The main result is that Random Forest achieved the highest test accuracy at 97.88%, while XGBoost achieved the strongest macro F1-score at 0.66. The feature-engineering contribution is especially important: overall_productivity, a feature combining study hours and normalized attendance, was the top feature in the Decision Tree, Random Forest, and XGBoost outputs.")

doc.h("2. Project Analysis and Dataset 3 Evidence Boundary", 1)
doc.p("The project contains multiple datasets and model outputs. For this report, only Dataset 3 files were used. Files associated with other datasets were identified during the project inspection and excluded from the evidence base.")
doc.add_table("Dataset 3 evidence files used in the report", [
    ["Artifact type", "Dataset 3 files used"],
    ["Dataset files", "data/StudentPerformanceFactors_dataset3_final.csv; data/StudentPerformanceFactors.csv; data/dataset3_cleaned.csv"],
    ["Source code", "Dataset 3 model scripts, Dataset 3 feature-engineering script, and the Dataset 3 preprocessing script that writes the cleaned Dataset 3 outputs"],
    ["Reports", "reports/dataset3 preprocessing, feature-engineering, model result, and SVM result files"],
    ["Tables", "tables/dataset3 cleaning, missing-value, feature-summary, feature-importance, and SVM metric files"],
    ["Prediction outputs", "outputs/dataset3 prediction files for Decision Tree, Random Forest, Logistic Regression, SVM, and XGBoost"],
    ["Figures", "figures/dataset3 preprocessing, feature-engineering, model, SVM, and generated diagram figures"],
])
doc.add_image(figs["workflow"], "Complete Dataset 3 workflow diagram.", "The workflow diagram summarizes the implemented Dataset 3 pipeline from raw data through cleaning, feature engineering, target creation, model training, evaluation, and comparison.")

doc.h("3. Dataset Investigation", 1)
doc.p("The original source dataset used for Dataset 3 preparation is StudentPerformanceFactors.csv. The final modeling dataset is StudentPerformanceFactors_dataset3_final.csv. The original measurable outcome was Exam_Score; the raw dataset did not contain Performance_Class. Performance_Class was constructed later from Exam_Score to support a three-class classification strategy.")
doc.add_table("Dataset 3 structural characteristics", [
    ["Property", "Verified value"],
    ["Original dataset name", "StudentPerformanceFactors.csv"],
    ["Final dataset of interest", "StudentPerformanceFactors_dataset3_final.csv"],
    ["Number of records", str(len(final_rows))],
    ["Original feature count", str(len(original_features))],
    ["Engineered predictor count", "6"],
    ["Constructed target", "Performance_Class"],
    ["Final column count", str(len(final_cols))],
    ["Number of classes", "3"],
])
doc.add_table("Target class distribution", [
    ["Class", "Definition", "Records", "Share"],
    ["0", "Low performance: Exam_Score < 60", str(target_counts.get("0", 0)), f"{target_counts.get('0', 0) / len(final_rows) * 100:.2f}%"],
    ["1", "Medium performance: 60 <= Exam_Score < 75", str(target_counts.get("1", 0)), f"{target_counts.get('1', 0) / len(final_rows) * 100:.2f}%"],
    ["2", "High performance: Exam_Score >= 75", str(target_counts.get("2", 0)), f"{target_counts.get('2', 0) / len(final_rows) * 100:.2f}%"],
])

doc.h("4. Original Features", 1)
doc.p("Dataset 3 originally contained 20 features. These variables describe study behavior, attendance, background context, school conditions, previous achievement, and the final exam score used to construct the classification target.")
feature_rows = [["Feature", "Data type/category", "Explanation"]]
feature_explanations = {
    "Hours_Studied": "Number of hours studied by the student.",
    "Attendance": "Student attendance percentage.",
    "Parental_Involvement": "Level of parental involvement.",
    "Access_to_Resources": "Level of learning resource access.",
    "Extracurricular_Activities": "Participation in extracurricular activities.",
    "Sleep_Hours": "Daily sleep duration.",
    "Previous_Scores": "Prior academic score.",
    "Motivation_Level": "Student motivation level.",
    "Internet_Access": "Whether internet access is available.",
    "Tutoring_Sessions": "Number of tutoring sessions.",
    "Family_Income": "Family income level.",
    "Teacher_Quality": "Teacher quality category.",
    "School_Type": "School type category.",
    "Peer_Influence": "Peer influence category.",
    "Physical_Activity": "Physical activity level.",
    "Learning_Disabilities": "Learning disability indicator.",
    "Parental_Education_Level": "Parental education level.",
    "Distance_from_Home": "Distance between home and school.",
    "Gender": "Student gender.",
    "Exam_Score": "Original numeric outcome used to construct Performance_Class.",
}
numeric = {"Hours_Studied", "Attendance", "Sleep_Hours", "Previous_Scores", "Tutoring_Sessions", "Physical_Activity", "Exam_Score"}
for f in original_features:
    feature_rows.append([f, "Numeric" if f in numeric else "Categorical", feature_explanations[f]])
doc.add_table("Original Dataset 3 features", feature_rows)

doc.h("5. Data Cleaning and Preprocessing", 1)
doc.p("The preprocessing script checked duplicates, missing values, data types, categorical columns, numeric columns, and selected distributions. It removed duplicate rows after checking, but the verified duplicate count was zero. Missing values were handled with median imputation for numeric columns and most-frequent imputation for categorical columns. Categorical variables were converted using label encoding.")
doc.p("Outlier handling was performed through interquartile-range clipping for Hours_Studied, Attendance, Previous_Scores, Sleep_Hours, and Exam_Score. The cleaned Dataset 3 file contained no missing values after preprocessing.")
doc.add_table("Missing values before cleaning", [
    ["Column", "Missing values"],
    ["Teacher_Quality", "78"],
    ["Parental_Education_Level", "90"],
    ["Distance_from_Home", "67"],
    ["All other original columns", "0"],
])
doc.add_image(figs["missing"], "Dataset 3 missing-value heatmap.", "The heatmap visualizes the missing-value pattern before imputation and confirms why categorical imputation was required for three original variables.")
for key, caption in [
    ("hours", "Hours_Studied distribution after preprocessing."),
    ("attendance", "Attendance distribution after preprocessing."),
    ("previous", "Previous_Scores distribution after preprocessing."),
    ("sleep", "Sleep_Hours distribution after preprocessing."),
    ("exam", "Exam_Score distribution after preprocessing and outlier clipping."),
]:
    doc.add_image(figs[key], caption, "This distribution figure documents the shape of a key Dataset 3 numeric variable after preprocessing.")
doc.add_image(figs["pre_corr"], "Dataset 3 correlation heatmap before engineered-feature expansion.", "The correlation heatmap provides a baseline view of relationships among numeric encoded variables before the engineered feature set is added.")

doc.h("6. Feature Engineering and Research Innovation", 1)
doc.p("The feature-engineering stage added six new features. These variables translate raw study behavior, sleep, attendance, and performance history into more interpretable predictive indicators. This is the central research innovation of Dataset 3 because it moves beyond direct raw inputs and creates interaction-style features that represent study efficiency, attendance normalization, sleep adequacy, score movement, score proportionality, and overall productivity.")
rows = [["Engineered feature", "Formula", "Purpose", "Expected impact"]]
for row in engineered_features:
    rows.append(list(row))
doc.add_table("Engineered Dataset 3 features", rows)
doc.add_image(figs["fe_framework"], "Feature engineering framework.", "The framework shows how original student-performance factors were transformed into engineered features and then filtered into the final training feature set.")
doc.add_image(figs["post_corr"], "Dataset 3 correlation heatmap after feature engineering.", "The post-engineering heatmap shows how the additional features changed the numerical relationship structure available to the models.")
doc.add_image(figs["post_corr2"], "Additional Dataset 3 post-engineering correlation heatmap.", "This saved project figure provides a second generated view of Dataset 3 after the engineered variables were introduced.")

doc.h("7. Target Variable Construction", 1)
doc.p("Performance_Class was created by applying threshold rules to Exam_Score. Scores below 60 were mapped to class 0, scores from 60 to below 75 were mapped to class 1, and scores of 75 or above were mapped to class 2. This converts the original continuous exam outcome into an ordinal three-class classification task.")
doc.p("The target formulation was selected because it supports supervised classification of low, medium, and high student performance levels. This framing is practical for educational intervention because it separates students needing support from medium-performing students and high-performing students.")
doc.add_image(figs["target"], "Dataset 3 target distribution.", "The figure shows the strong dominance of class 1 in the constructed target, which affects how model results should be interpreted.")
doc.add_image(figs["perf_class"], "Performance class distribution.", "This saved Dataset 3 figure confirms the same target distribution pattern after class construction.")

doc.h("8. Feature Selection and Data Leakage Control", 1)
doc.p("All models excluded Performance_Class, Exam_Score, performance_trend, and score_ratio from the predictor matrix. Performance_Class is the target variable and cannot be used as an input. Exam_Score directly defines Performance_Class, so including it would allow the model to infer the target from the answer variable. performance_trend and score_ratio also use Exam_Score in their formulas; retaining them would leak target information into training.")
doc.p("Removing these variables improves model validity by requiring each algorithm to predict performance class from available student factors and non-leaking engineered features rather than from the final exam score itself.")
doc.add_table("Columns excluded from model training", [
    ["Excluded column", "Reason for exclusion"],
    ["Performance_Class", "Constructed target variable; used as y, not as a predictor."],
    ["Exam_Score", "Direct source of the target thresholds; would create direct leakage."],
    ["performance_trend", "Formula includes Exam_Score; would leak outcome information."],
    ["score_ratio", "Formula includes Exam_Score; would leak outcome information."],
])
doc.add_table("Final training feature set used by Dataset 3 models", [["Feature number", "Training feature"]] + [[str(i + 1), f] for i, f in enumerate(training_features)])

doc.h("9. Experimental Design", 1)
doc.p("Each Dataset 3 model used a stratified 80/20 train-test split with random_state=42. The final dataset contains 6,607 records, giving 5,285 training records and 1,322 testing records. Stratification was used to preserve the class distribution in both partitions.")
doc.add_table("Experimental setup", [
    ["Setting", "Value"],
    ["Dataset size", "6,607 records"],
    ["Training percentage", "80%"],
    ["Testing percentage", "20%"],
    ["Training records", "5,285"],
    ["Testing records", "1,322"],
    ["Random state", "42"],
    ["Split strategy", "Stratified by Performance_Class"],
    ["Evaluation metrics", "Accuracy, precision, recall, F1-score, confusion matrix"],
])
doc.p("Accuracy was selected to summarize overall correctness. Precision was selected to measure how reliable each positive class prediction is. Recall was selected to evaluate how well each class is recovered, which is important because Dataset 3 is highly imbalanced. F1-score was selected because it balances precision and recall. The confusion matrix was selected to reveal which classes are confused with each other.")

doc.h("10. Machine Learning Model Development", 1)
doc.add_image(figs["model_framework"], "Model development framework.", "The model development framework shows the five Dataset 3 algorithms trained from the same final dataset and compared using common evaluation outputs.")
doc.add_table("Dataset 3 model specifications", [
    ["Model", "Parameters and process verified from source code", "Features used"],
    ["Decision Tree", "Gini criterion, max_depth=10, min_samples_split=5, min_samples_leaf=2, class_weight='balanced', random_state=42.", "The 23-feature leakage-controlled training set."],
    ["Random Forest", "300 estimators, Gini criterion, max_depth=12, min_samples_split=5, min_samples_leaf=2, class_weight='balanced', random_state=42, n_jobs=-1.", "The 23-feature leakage-controlled training set."],
    ["Logistic Regression", "max_iter=5000, class_weight='balanced', random_state=42.", "The 23-feature leakage-controlled training set."],
    ["SVM", "StandardScaler applied; GridSearchCV with 5-fold CV, scoring='accuracy', RBF kernel grid over C=[0.1,1,10] and gamma=['scale','auto']; best C=10, gamma='scale', kernel='rbf'.", "The 23-feature leakage-controlled training set, scaled before SVM fitting."],
    ["XGBoost", "n_estimators=300, max_depth=6, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, random_state=42, eval_metric='mlogloss'.", "The 23-feature leakage-controlled training set."],
])

doc.h("11. Results and Performance Analysis", 1)
rows = [["Model", "Accuracy", "Macro precision", "Macro recall", "Macro F1-score", "Weighted F1-score"]]
for name, m in model_reports.items():
    rows.append([name, pct(m["accuracy"]), f'{m["macro_precision"]:.2f}', f'{m["macro_recall"]:.2f}', f'{m["macro_f1"]:.2f}', f'{m["weighted_f1"]:.2f}'])
doc.add_table("Model performance comparison", rows, "Random Forest is the best model by accuracy; XGBoost is the best by macro F1-score.")
doc.add_table("Model interpretation summary", [
    ["Criterion", "Model", "Interpretation"],
    ["Best-performing model", "Random Forest", "Highest test accuracy at 97.88% and strong weighted F1-score."],
    ["Worst-performing model", "Logistic Regression", "Lowest test accuracy at 79.58%, with many medium-performance students misclassified into minority classes."],
    ["Most stable model", "Random Forest", "Ensemble averaging gives high accuracy and strong weighted performance while avoiding the instability of a single tree."],
    ["Most practical deployment model", "Random Forest", "Combines high performance, interpretable feature importance, and robust implementation."],
])
for name in ["Decision Tree", "Random Forest", "Logistic Regression", "SVM", "XGBoost"]:
    m = model_reports[name]
    doc.h(f"11.{list(model_reports).index(name) + 1}. {name} Results", 2)
    doc.p(f"{name} achieved {pct(m['accuracy'])} accuracy, macro precision {m['macro_precision']:.2f}, macro recall {m['macro_recall']:.2f}, macro F1-score {m['macro_f1']:.2f}, and weighted F1-score {m['weighted_f1']:.2f}.")
    doc.add_image(model_figs[name]["accuracy"], f"{name} accuracy figure.", f"This figure displays the test accuracy obtained by the {name} model on Dataset 3.")
    doc.add_image(model_figs[name]["confusion"], f"{name} confusion matrix.", f"The confusion matrix shows the actual-versus-predicted class pattern for {name}. It is especially useful for judging minority-class behavior under the imbalanced target distribution.")

doc.h("12. Figures and Visualization", 1)
doc.p("All embedded figures in this report are Dataset 3 figures generated by Python or diagrams generated specifically for the Dataset 3 report. No figures from other datasets are included.")
for name in ["Decision Tree", "Random Forest", "Logistic Regression", "XGBoost"]:
    doc.add_image(model_figs[name]["importance"], f"{name} feature-importance figure.", f"This feature-importance visualization identifies the strongest predictors for {name}. The tree-based models consistently identify overall_productivity as the leading feature.")
doc.p("SVM does not have a directly comparable feature-importance figure in the generated Dataset 3 outputs because the selected model uses an RBF kernel.")

doc.h("13. Discussion", 1)
doc.p("The Dataset 3 results show that feature engineering was effective. overall_productivity emerged as the top feature in Decision Tree, Random Forest, and XGBoost, confirming that combining attendance with study hours created a stronger predictor than isolated raw variables alone. study_efficiency and attendance_score also appear in important feature lists, supporting the value of engineered behavioral indicators.")
doc.p("The model differences are consistent with their learning mechanisms. Random Forest performs best because the ensemble reduces the instability of a single decision tree while preserving nonlinear feature interactions. XGBoost performs nearly as well and achieves the highest macro F1-score, suggesting better balance across classes. SVM also performs strongly after scaling and parameter tuning. Logistic Regression is the weakest by accuracy because a linear boundary is less able to represent the nonlinear relationships in the engineered Dataset 3 feature space.")
doc.p("The main limitation is class imbalance: class 1 represents more than 97% of the data. This means that high accuracy can hide weaker performance on low- and high-performance classes. The practical implication is that Random Forest is suitable as the current deployment candidate for general prediction, but future research should improve minority-class sensitivity before using the model for high-stakes student intervention.")

doc.h("14. Conclusion", 1)
doc.p("This report documented the complete Dataset 3 machine learning workflow using only StudentPerformanceFactors_dataset3_final.csv and Dataset 3 artifacts. The project prepared 6,607 records, cleaned missing values, encoded categorical variables, clipped selected numeric outliers, engineered six new variables, constructed a three-class Performance_Class target, and trained five supervised classifiers.")
doc.p("The strongest research contribution is the feature-engineering framework. In particular, overall_productivity combines Hours_Studied with normalized Attendance and became the most important feature in the main tree-based models. This supports the conclusion that meaningful behavioral interaction features improve the representation of student performance factors.")
doc.p("Random Forest is the best-performing model by test accuracy at 97.88% and is the most practical model for deployment due to its strong performance and interpretable feature-importance output. XGBoost is the strongest secondary model because it achieved the best macro F1-score. Future work should address target imbalance through resampling, threshold tuning, class-weight optimization, and additional validation on external student-performance data.")

figure_list = list(doc.figure_list)
table_list = list(doc.table_list)
for idx, block in enumerate(doc.body):
    if block == "__FIGURE_LIST_PLACEHOLDER__":
        doc.body[idx] = "".join(paragraph(item) for item in figure_list)
    elif block == "__TABLE_LIST_PLACEHOLDER__":
        doc.body[idx] = "".join(paragraph(item) for item in table_list)

sect = '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1080" w:right="900" w:bottom="1080" w:left="900" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
document_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
  xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
  xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
  xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>{''.join(doc.body)}{sect}</w:body></w:document>'''

styles_xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/></w:rPr><w:pPr><w:spacing w:after="140"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:b/><w:sz w:val="40"/><w:color w:val="0F766E"/></w:rPr><w:pPr><w:spacing w:after="240"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:i/><w:sz w:val="28"/><w:color w:val="52606D"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:b/><w:sz w:val="30"/><w:color w:val="0F766E"/></w:rPr><w:pPr><w:keepNext/><w:spacing w:before="360" w:after="180"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:b/><w:sz w:val="25"/></w:rPr><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="Caption"/><w:basedOn w:val="Normal"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:i/><w:sz w:val="19"/><w:color w:val="52606D"/></w:rPr><w:pPr><w:spacing w:after="180"/></w:pPr></w:style>
<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:color="D9E2EC"/><w:left w:val="single" w:sz="4" w:color="D9E2EC"/><w:bottom w:val="single" w:sz="4" w:color="D9E2EC"/><w:right w:val="single" w:sz="4" w:color="D9E2EC"/><w:insideH w:val="single" w:sz="4" w:color="D9E2EC"/><w:insideV w:val="single" w:sz="4" w:color="D9E2EC"/></w:tblBorders></w:tblPr></w:style>
</w:styles>'''

rels_xml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
for rid, target in doc.rels:
    rels_xml.append(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="{target}"/>')
rels_xml.append("</Relationships>")

content_types = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">']
content_types.extend([
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
    '<Default Extension="xml" ContentType="application/xml"/>',
    '<Default Extension="png" ContentType="image/png"/>',
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>',
    '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>',
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
    '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
])
content_types.append("</Types>")

root_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>'''

core = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Student Performance Factors Dataset 3 Supervisor Report</dc:title>
<dc:subject>Machine learning report for Dataset 3</dc:subject>
<dc:creator>Codex</dc:creator>
<cp:lastModifiedBy>Codex</cp:lastModifiedBy>
<dcterms:created xsi:type="dcterms:W3CDTF">{dt.datetime.utcnow().isoformat()}Z</dcterms:created>
<dcterms:modified xsi:type="dcterms:W3CDTF">{dt.datetime.utcnow().isoformat()}Z</dcterms:modified>
</cp:coreProperties>'''

app = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>Codex</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0000</AppVersion>
</Properties>'''

OUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", "".join(content_types))
    z.writestr("_rels/.rels", root_rels)
    z.writestr("docProps/core.xml", core)
    z.writestr("docProps/app.xml", app)
    z.writestr("word/document.xml", document_xml)
    z.writestr("word/styles.xml", styles_xml)
    z.writestr("word/_rels/document.xml.rels", "".join(rels_xml))
    for media_name, path in doc.media:
        z.write(path, f"word/media/{media_name}")

print(OUT)
print(f"figures={doc.figure_no}")
print(f"tables={doc.table_no}")
