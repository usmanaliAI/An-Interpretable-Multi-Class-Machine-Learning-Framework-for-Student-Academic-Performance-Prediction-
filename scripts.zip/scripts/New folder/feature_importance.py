"""
Feature importance analysis for Dataset 3.

The Random Forest model is used because it achieved the strongest existing
holdout accuracy in the project and provides stable impurity-based importance.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = PROJECT_ROOT / "data" / "StudentPerformanceFactors_dataset3_final.csv"
FIGURES_DIR = PROJECT_ROOT / "figures"
TABLES_DIR = PROJECT_ROOT / "tables"

TARGET_COLUMN = "Performance_Class"
LEAKAGE_COLUMNS = [TARGET_COLUMN, "Exam_Score", "performance_trend", "score_ratio"]
RANDOM_STATE = 42


def ensure_directories() -> None:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)


def load_dataset3() -> tuple[pd.DataFrame, pd.Series]:
    data = pd.read_csv(DATASET_PATH)
    x = data.drop(columns=LEAKAGE_COLUMNS, errors="ignore")
    y = data[TARGET_COLUMN]
    return x, y


def train_best_model(x: pd.DataFrame, y: pd.Series) -> RandomForestClassifier:
    x_train, _, y_train, _ = train_test_split(
        x,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    model = RandomForestClassifier(
        n_estimators=300,
        criterion="gini",
        max_depth=12,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    return model


def compute_feature_importance(model: RandomForestClassifier, feature_names: pd.Index) -> pd.DataFrame:
    importance = pd.DataFrame(
        {
            "Feature": feature_names,
            "Importance": model.feature_importances_,
        }
    )
    return importance.sort_values("Importance", ascending=False)


def plot_feature_importance(importance: pd.DataFrame) -> Path:
    sns.set_theme(style="whitegrid", font_scale=1.1)
    top_features = importance.head(15)

    plt.figure(figsize=(10, 7))
    axis = sns.barplot(
        data=top_features,
        x="Importance",
        y="Feature",
        color="#2A9D8F",
    )
    axis.set_title("Top 15 Feature Importance Scores - Random Forest", weight="bold")
    axis.set_xlabel("Importance Score")
    axis.set_ylabel("Feature")
    sns.despine(left=True, bottom=True)
    plt.tight_layout()

    figure_path = FIGURES_DIR / "dataset3_random_forest_feature_importance_publication.png"
    plt.savefig(figure_path, dpi=300, bbox_inches="tight")
    plt.close()
    return figure_path


def main() -> None:
    ensure_directories()
    x, y = load_dataset3()
    model = train_best_model(x, y)
    importance = compute_feature_importance(model, x.columns)

    table_path = TABLES_DIR / "dataset3_random_forest_feature_importance_publication.csv"
    importance.to_csv(table_path, index=False)
    figure_path = plot_feature_importance(importance)

    print("\nDataset 3: Random Forest Feature Importance")
    print("===========================================")
    print(importance.head(15).round(4).to_string(index=False))
    print("\nFeature importance table saved in:", table_path)
    print("Feature importance figure saved in:", figure_path)


if __name__ == "__main__":
    main()
