"""
SHAP explainability analysis for Dataset 3.

This script trains the best tree-based model used in the project, generates a
global SHAP summary plot, and saves global feature importance values.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = PROJECT_ROOT / "data" / "StudentPerformanceFactors_dataset3_final.csv"
FIGURES_DIR = PROJECT_ROOT / "figures"
TABLES_DIR = PROJECT_ROOT / "tables"

TARGET_COLUMN = "Performance_Class"
LEAKAGE_COLUMNS = [TARGET_COLUMN, "Exam_Score", "performance_trend", "score_ratio"]
RANDOM_STATE = 42
MAX_SHAP_SAMPLES = 1000


def ensure_directories() -> None:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)


def load_dataset3() -> tuple[pd.DataFrame, pd.Series]:
    data = pd.read_csv(DATASET_PATH)
    x = data.drop(columns=LEAKAGE_COLUMNS, errors="ignore")
    y = data[TARGET_COLUMN]
    return x, y


def train_tree_model(x: pd.DataFrame, y: pd.Series) -> tuple[RandomForestClassifier, pd.DataFrame]:
    x_train, x_test, y_train, _ = train_test_split(
        x,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    model = RandomForestClassifier(
        n_estimators=300,
        criterion="gini",
        max_depth=12,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    return model, x_test


def sample_for_shap(x_test: pd.DataFrame) -> pd.DataFrame:
    sample_size = min(MAX_SHAP_SAMPLES, len(x_test))
    return x_test.sample(n=sample_size, random_state=RANDOM_STATE)


def normalize_shap_values(shap_values: object) -> np.ndarray:
    values = np.asarray(shap_values)

    if values.ndim == 3:
        if values.shape[0] == 3:
            values = np.mean(np.abs(values), axis=0)
        else:
            values = np.mean(np.abs(values), axis=2)
    elif values.ndim == 2:
        values = np.abs(values)
    else:
        raise ValueError(f"Unsupported SHAP value dimensions: {values.shape}")

    return values


def global_shap_importance(shap_values: object, feature_names: pd.Index) -> pd.DataFrame:
    values = normalize_shap_values(shap_values)
    mean_abs_shap = values.mean(axis=0)
    importance = pd.DataFrame(
        {
            "Feature": feature_names,
            "Mean absolute SHAP value": mean_abs_shap,
        }
    )
    return importance.sort_values("Mean absolute SHAP value", ascending=False)


def values_for_summary_plot(shap_values: object, x_sample: pd.DataFrame) -> object:
    if isinstance(shap_values, list):
        return shap_values

    values = np.asarray(shap_values)
    if values.ndim == 3 and values.shape[:2] == x_sample.shape:
        return [values[:, :, class_index] for class_index in range(values.shape[2])]
    if values.ndim == 3:
        return [values[class_index, :, :] for class_index in range(values.shape[0])]
    return shap_values


def save_summary_plot(shap_values: object, x_sample: pd.DataFrame) -> Path:
    figure_path = FIGURES_DIR / "dataset3_random_forest_shap_summary.png"
    shap.summary_plot(values_for_summary_plot(shap_values, x_sample), x_sample, show=False, max_display=15)
    plt.title("SHAP Summary Plot - Random Forest", weight="bold")
    plt.tight_layout()
    plt.savefig(figure_path, dpi=300, bbox_inches="tight")
    plt.close()
    return figure_path


def main() -> None:
    ensure_directories()
    x, y = load_dataset3()
    model, x_test = train_tree_model(x, y)
    x_sample = sample_for_shap(x_test)

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(x_sample)

    importance = global_shap_importance(shap_values, x_sample.columns)
    table_path = TABLES_DIR / "dataset3_random_forest_shap_global_importance.csv"
    importance.to_csv(table_path, index=False)
    figure_path = save_summary_plot(shap_values, x_sample)

    print("\nDataset 3: Global SHAP Feature Importance")
    print("=========================================")
    print(importance.head(15).round(6).to_string(index=False))
    print("\nSHAP analysis indicates that features with the largest mean absolute SHAP")
    print("values contribute most strongly to global model predictions.")
    print("\nSHAP importance table saved in:", table_path)
    print("SHAP summary plot saved in:", figure_path)


if __name__ == "__main__":
    main()
