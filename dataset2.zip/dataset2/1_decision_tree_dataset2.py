import pandas as pd
import os

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

print("=" * 80)
print("MODEL 1 - DECISION TREE - DATASET 2")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

# ------------------------------------------------
# MAIN PATHS
# ------------------------------------------------
output_path = os.path.join(project_root, "outputs")
report_path = os.path.join(project_root, "reports")
table_path = os.path.join(project_root, "tables")

# ------------------------------------------------
# PROFESSIONAL FIGURE FOLDERS
# ------------------------------------------------
figure_root = os.path.join(project_root, "figures")

dataset2_figure_path = os.path.join(
    figure_root,
    "dataset2"
)

model_figure_path = os.path.join(
    dataset2_figure_path,
    "models"
)

# ------------------------------------------------
# CREATE FOLDERS
# ------------------------------------------------
os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)

os.makedirs(figure_root, exist_ok=True)
os.makedirs(dataset2_figure_path, exist_ok=True)
os.makedirs(model_figure_path, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================
print("\nLoading processed dataset...")

X_train = pd.read_csv(
    os.path.join(output_path, "X_train_dataset2.csv")
)

X_test = pd.read_csv(
    os.path.join(output_path, "X_test_dataset2.csv")
)

y_train = pd.read_csv(
    os.path.join(output_path, "y_train_dataset2.csv")
).squeeze()

y_test = pd.read_csv(
    os.path.join(output_path, "y_test_dataset2.csv")
).squeeze()

print("Dataset loaded successfully!")

print("\nTraining Shape:")
print(X_train.shape)

print("\nTesting Shape:")
print(X_test.shape)

print("\nFeatures Used:")
print(X_train.columns.tolist())

# ============================================================
# ENCODE CATEGORICAL FEATURES
# ============================================================
print("\nEncoding categorical columns...")

X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)

# Align train and test columns
X_train, X_test = X_train.align(
    X_test,
    join='left',
    axis=1,
    fill_value=0
)

print("Encoding completed!")

# ============================================================
# MODEL CREATION
# ============================================================
print("\nCreating Decision Tree model...")

# PROFESSIONAL TUNED MODEL
model = DecisionTreeClassifier(
    criterion='entropy',
    max_depth=12,
    min_samples_split=8,
    min_samples_leaf=4,
    class_weight='balanced',
    random_state=42
)

# ============================================================
# TRAIN MODEL
# ============================================================
print("\nTraining model...")

model.fit(X_train, y_train)

print("Training completed!")

# ============================================================
# PREDICTIONS
# ============================================================
print("\nMaking predictions...")

y_pred = model.predict(X_test)

# ============================================================
# EVALUATION
# ============================================================
print("\nEvaluating model...")

accuracy = accuracy_score(
    y_test,
    y_pred
)

report = classification_report(
    y_test,
    y_pred
)

matrix = confusion_matrix(
    y_test,
    y_pred
)

# ============================================================
# RESULTS
# ============================================================
print("\n" + "=" * 80)
print("DECISION TREE RESULTS - DATASET 2")
print("=" * 80)

print("\nAccuracy:")
print(round(accuracy, 4))

print("\nClassification Report:")
print(report)

print("\nConfusion Matrix:")
print(matrix)

# ============================================================
# FEATURE IMPORTANCE
# ============================================================
importance_df = pd.DataFrame({
    'Feature': X_train.columns,
    'Importance': model.feature_importances_
})

importance_df = importance_df.sort_values(
    by='Importance',
    ascending=False
)

print("\nTop Feature Importance:")
print(importance_df.head(10))

# ============================================================
# SAVE FEATURE IMPORTANCE TABLE
# ============================================================
importance_df.to_csv(
    os.path.join(
        table_path,
        "dataset2_decision_tree_feature_importance.csv"
    ),
    index=False
)

print("\nFeature importance table saved!")

# ============================================================
# CONFUSION MATRIX FIGURE
# ============================================================
print("\nCreating confusion matrix figure...")

plt.figure(figsize=(8, 6))

sns.heatmap(
    matrix,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.title(
    "Decision Tree Confusion Matrix - Dataset 2",
    fontsize=14
)

plt.xlabel("Predicted Class")
plt.ylabel("Actual Class")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset2_decision_tree_confusion_matrix.png"
    )
)

plt.close()

print("Confusion matrix figure saved!")

# ============================================================
# FEATURE IMPORTANCE FIGURE
# ============================================================
print("\nCreating feature importance figure...")

top_features = importance_df.head(10)

plt.figure(figsize=(10, 6))

sns.barplot(
    data=top_features,
    x='Importance',
    y='Feature'
)

plt.title(
    "Top 10 Important Features - Decision Tree",
    fontsize=14
)

plt.xlabel("Importance Score")
plt.ylabel("Features")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset2_decision_tree_feature_importance.png"
    )
)

plt.close()

print("Feature importance figure saved!")

# ============================================================
# ACCURACY FIGURE
# ============================================================
print("\nCreating accuracy figure...")

plt.figure(figsize=(5, 5))

plt.bar(
    ['Decision Tree'],
    [accuracy]
)

plt.ylim(0, 1)

plt.title("Decision Tree Accuracy - Dataset 2")

plt.ylabel("Accuracy")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset2_decision_tree_accuracy.png"
    )
)

plt.close()

print("Accuracy figure saved!")

# ============================================================
# SAVE RESULTS REPORT
# ============================================================
result_file = os.path.join(
    report_path,
    "dataset2_decision_tree_results.txt"
)

with open(result_file, "w", encoding="utf-8") as f:

    f.write("MODEL 1 - DECISION TREE - DATASET 2\n")
    f.write("=" * 70 + "\n\n")

    f.write(f"Accuracy: {accuracy}\n\n")

    f.write("Classification Report:\n")
    f.write(report)

    f.write("\nConfusion Matrix:\n")
    f.write(str(matrix))

    f.write("\n\nTop Feature Importance:\n")
    f.write(str(importance_df.head(10)))

print("\nResults report saved!")
print(result_file)

# ============================================================
# SAVE PREDICTIONS
# ============================================================
prediction_df = pd.DataFrame({
    'Actual': y_test,
    'Predicted': y_pred
})

prediction_df.to_csv(
    os.path.join(
        output_path,
        "dataset2_decision_tree_predictions.csv"
    ),
    index=False
)

print("\nPrediction file saved!")

# ============================================================
# FINAL MESSAGE
# ============================================================
print("\nMODEL COMPLETED SUCCESSFULLY!")
print("=" * 80)