import pandas as pd
import os
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

print("=" * 80)
print("DATASET 2 PREPROCESSING")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

# Main folders
data_path = os.path.join(project_root, "data")
output_path = os.path.join(project_root, "outputs")
report_path = os.path.join(project_root, "reports")
table_path = os.path.join(project_root, "tables")

# ============================================================
# PROFESSIONAL FIGURE FOLDER STRUCTURE
# ============================================================
figure_root = os.path.join(project_root, "figures")

dataset2_figure_path = os.path.join(
    figure_root,
    "dataset2_figures"
)

preprocessing_figure_path = os.path.join(
    dataset2_figure_path,
    "preprocessing"
)

# ============================================================
# CREATE FOLDERS
# ============================================================
os.makedirs(output_path, exist_ok=True)
os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)

os.makedirs(figure_root, exist_ok=True)
os.makedirs(dataset2_figure_path, exist_ok=True)
os.makedirs(preprocessing_figure_path, exist_ok=True)

# ============================================================
# LOAD DATASET
# ============================================================
print("\nLoading dataset...")

df = pd.read_csv(
    os.path.join(data_path, "StudentGradesDataset.csv")
)

print("Dataset loaded successfully!")

# ============================================================
# BASIC INFORMATION
# ============================================================
print("\nDataset Shape:")
print(df.shape)

print("\nColumns:")
print(df.columns.tolist())

# ============================================================
# MISSING VALUES VISUALIZATION
# ============================================================
print("\nCreating missing values visualization...")

missing_values = df.isnull().sum()

plt.figure(figsize=(14, 6))

missing_values.plot(kind='bar')

plt.title("Dataset 2 - Missing Values Before Cleaning")
plt.xlabel("Features")
plt.ylabel("Missing Values")

plt.xticks(rotation=45)

plt.tight_layout()

plt.savefig(
    os.path.join(
        preprocessing_figure_path,
        "dataset2_missing_values.png"
    )
)

plt.close()

print("Missing values figure saved!")

# ============================================================
# REMOVE HIGH MISSING VALUE SUBJECTS
# ============================================================
print("\nRemoving subjects with huge missing values...")

drop_columns = [
    'Physic',
    'Chemistry',
    'Biology',
    'History',
    'Geography',
    'Economics',
    'Sociology',
    'philosophy'
]

df.drop(columns=drop_columns, inplace=True)

print("Columns removed successfully!")

# ============================================================
# REMOVE USELESS COLUMNS
# ============================================================
print("\nRemoving useless columns...")

df.drop(columns=[
    'Serial No',
    'School Name'
], inplace=True)

# ============================================================
# CLEANING SUMMARY TABLE
# ============================================================
print("\nSaving cleaning summary table...")

cleaning_summary = pd.DataFrame({
    'Stage': ['Raw Dataset', 'Cleaned Dataset'],
    'Rows': [16823, df.shape[0]],
    'Columns': [20, df.shape[1]]
})

cleaning_summary.to_csv(
    os.path.join(
        table_path,
        "dataset2_cleaning_summary.csv"
    ),
    index=False
)

print("Cleaning summary table saved!")

# ============================================================
# REMAINING SUBJECTS
# ============================================================
subjects = [
    'Religion',
    'Kurdish',
    'Arabic',
    'English',
    'Math',
    'Computer',
    'Science',
    'Social'
]

# ============================================================
# HANDLE MISSING VALUES
# ============================================================
print("\nHandling missing values...")

imputer = SimpleImputer(strategy='median')

df[subjects] = imputer.fit_transform(df[subjects])

print("Missing values handled successfully!")

# ============================================================
# FEATURE ENGINEERING
# ============================================================
print("\nCreating engineered features...")

# Average score
df['avg_score'] = df[subjects].mean(axis=1)

# Total score
df['total_score'] = df[subjects].sum(axis=1)

# Language score
df['language_score'] = df[
    ['Kurdish', 'Arabic', 'English']
].mean(axis=1)

# STEM score
df['stem_score'] = df[
    ['Math', 'Computer', 'Science']
].mean(axis=1)

# Study consistency
df['study_consistency'] = df[subjects].std(axis=1)

print("Feature engineering completed!")

# ============================================================
# ENGINEERED FEATURE VISUALIZATIONS
# ============================================================
print("\nCreating engineered feature figures...")

engineered_features = [
    'language_score',
    'stem_score',
    'study_consistency'
]

for feature in engineered_features:

    plt.figure(figsize=(8, 5))

    sns.histplot(df[feature], bins=30)

    plt.title(f"{feature} Distribution")

    plt.xlabel(feature)
    plt.ylabel("Frequency")

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            preprocessing_figure_path,
            f"{feature}_distribution.png"
        )
    )

    plt.close()

print("Engineered feature figures saved!")

# ============================================================
# CREATE TARGET CLASSES
# ============================================================
print("\nCreating target classes...")

def create_target(score):

    if score < 50:
        return 0

    elif score < 75:
        return 1

    else:
        return 2

df['target'] = df['avg_score'].apply(create_target)

print("\nTarget Distribution:")
print(df['target'].value_counts())

# ============================================================
# TARGET DISTRIBUTION FIGURE
# ============================================================
print("\nCreating target distribution figure...")

plt.figure(figsize=(7, 5))

sns.countplot(x=df['target'])

plt.title("Dataset 2 - Target Class Distribution")

plt.xlabel("Target Class")
plt.ylabel("Count")

plt.tight_layout()

plt.savefig(
    os.path.join(
        preprocessing_figure_path,
        "dataset2_target_distribution.png"
    )
)

plt.close()

print("Target distribution figure saved!")

# ============================================================
# REMOVE LEAKAGE FEATURES
# ============================================================
print("\nRemoving leakage features...")

X = df.drop(columns=[
    'avg_score',
    'total_score',
    'target'
])

y = df['target']

print("\nFinal Features Used:")
print(X.columns.tolist())

# ============================================================
# CORRELATION HEATMAP
# ============================================================
print("\nCreating correlation heatmap...")

plt.figure(figsize=(14, 10))

sns.heatmap(
    df.corr(numeric_only=True),
    annot=False,
    cmap='coolwarm'
)

plt.title("Dataset 2 - Feature Correlation Heatmap")

plt.tight_layout()

plt.savefig(
    os.path.join(
        preprocessing_figure_path,
        "dataset2_correlation_heatmap.png"
    )
)

plt.close()

print("Correlation heatmap saved!")

# ============================================================
# TRAIN TEST SPLIT
# ============================================================
print("\nCreating train/test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTrain Shape:")
print(X_train.shape)

print("\nTest Shape:")
print(X_test.shape)

# ============================================================
# SAVE TRAIN TEST FILES
# ============================================================
print("\nSaving processed files...")

X_train.to_csv(
    os.path.join(output_path, "X_train_dataset2.csv"),
    index=False
)

X_test.to_csv(
    os.path.join(output_path, "X_test_dataset2.csv"),
    index=False
)

y_train.to_csv(
    os.path.join(output_path, "y_train_dataset2.csv"),
    index=False
)

y_test.to_csv(
    os.path.join(output_path, "y_test_dataset2.csv"),
    index=False
)

print("Processed files saved!")

# ============================================================
# SAVE PREPROCESSING REPORT
# ============================================================
report_file = os.path.join(
    report_path,
    "dataset2_preprocessing_report.txt"
)

with open(report_file, "w", encoding="utf-8") as f:

    f.write("DATASET 2 PREPROCESSING REPORT\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Dataset Shape: {df.shape}\n\n")

    f.write("Final Features Used:\n")
    f.write(str(X.columns.tolist()))
    f.write("\n\n")

    f.write("Target Distribution:\n")
    f.write(str(df['target'].value_counts()))

print("\nReport Saved:")
print(report_file)

# ============================================================
# SAVE FINAL CLEANED DATASET
# ============================================================
print("\nSaving final cleaned dataset...")

final_dataset = pd.concat([X, y], axis=1)

final_dataset.to_csv(
    os.path.join(data_path, "dataset2_cleaned.csv"),
    index=False
)

print("Final cleaned dataset saved!")

print("\nPREPROCESSING COMPLETED SUCCESSFULLY!")
print("=" * 80)