import pandas as pd
import os

import matplotlib.pyplot as plt
import seaborn as sns

print("=" * 80)
print("EDA - DATASET 2")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

data_path = os.path.join(project_root, "data")
report_path = os.path.join(project_root, "reports")
figure_path = os.path.join(project_root, "figures")

os.makedirs(report_path, exist_ok=True)
os.makedirs(figure_path, exist_ok=True)

# ============================================================
# LOAD CLEANED DATASET
# ============================================================

print("\nLoading cleaned dataset...")

df = pd.read_csv(
    os.path.join(data_path, "dataset2_cleaned.csv")
)

print("Dataset loaded successfully!")

# ============================================================
# BASIC INFORMATION
# ============================================================

print("\nDataset Shape:")
print(df.shape)

print("\nColumns:")
print(df.columns.tolist())

print("\nData Types:")
print(df.dtypes)

print("\nMissing Values:")
print(df.isnull().sum())

# ============================================================
# DESCRIPTIVE STATISTICS
# ============================================================

print("\nDescriptive Statistics:")
print(df.describe())

# Save statistics
stats_file = os.path.join(
    report_path,
    "dataset2_statistics.txt"
)

with open(stats_file, "w", encoding="utf-8") as f:

    f.write("DATASET 2 STATISTICS\n")
    f.write("=" * 60 + "\n\n")

    f.write(str(df.describe()))

print("\nStatistics report saved!")

# ============================================================
# TARGET DISTRIBUTION
# ============================================================

print("\nCreating target distribution plot...")

plt.figure(figsize=(8, 5))

sns.countplot(x='target', data=df)

plt.title("Target Class Distribution")
plt.xlabel("Target Class")
plt.ylabel("Count")

plt.savefig(
    os.path.join(
        figure_path,
        "dataset2_target_distribution.png"
    )
)

plt.close()

print("Target distribution plot saved!")

# ============================================================
# SUBJECT DISTRIBUTIONS
# ============================================================

subjects = [
    'Kurdish',
    'Arabic',
    'English',
    'Math',
    'Computer',
    'Science',
    'Social'
]

for subject in subjects:

    plt.figure(figsize=(8, 5))

    sns.histplot(
        df[subject],
        bins=20,
        kde=True
    )

    plt.title(f"{subject} Score Distribution")

    plt.savefig(
        os.path.join(
            figure_path,
            f"{subject}_distribution.png"
        )
    )

    plt.close()

print("\nSubject distributions saved!")

# ============================================================
# CORRELATION HEATMAP
# ============================================================

print("\nCreating correlation heatmap...")

numeric_df = df.select_dtypes(include=['int64', 'float64'])

plt.figure(figsize=(14, 10))

correlation_matrix = numeric_df.corr()

sns.heatmap(
    correlation_matrix,
    annot=True,
    cmap='coolwarm',
    fmt=".2f"
)

plt.title("Feature Correlation Heatmap")

plt.savefig(
    os.path.join(
        figure_path,
        "dataset2_correlation_heatmap.png"
    )
)

plt.close()

print("Correlation heatmap saved!")

# ============================================================
# BOXPLOTS
# ============================================================

for subject in subjects:

    plt.figure(figsize=(8, 5))

    sns.boxplot(x=df[subject])

    plt.title(f"{subject} Boxplot")

    plt.savefig(
        os.path.join(
            figure_path,
            f"{subject}_boxplot.png"
        )
    )

    plt.close()

print("\nBoxplots saved!")

# ============================================================
# ENGINEERED FEATURES ANALYSIS
# ============================================================

engineered_features = [
    'language_score',
    'stem_score',
    'study_consistency'
]

for feature in engineered_features:

    plt.figure(figsize=(8, 5))

    sns.histplot(
        df[feature],
        bins=20,
        kde=True
    )

    plt.title(f"{feature} Distribution")

    plt.savefig(
        os.path.join(
            figure_path,
            f"{feature}_distribution.png"
        )
    )

    plt.close()

print("\nEngineered feature plots saved!")

# ============================================================
# TARGET VS FEATURES
# ============================================================

for feature in engineered_features:

    plt.figure(figsize=(8, 5))

    sns.boxplot(
        x='target',
        y=feature,
        data=df
    )

    plt.title(f"{feature} vs Target")

    plt.savefig(
        os.path.join(
            figure_path,
            f"{feature}_vs_target.png"
        )
    )

    plt.close()

print("\nTarget vs feature plots saved!")

# ============================================================
# SAVE EDA REPORT
# ============================================================

eda_report = os.path.join(
    report_path,
    "dataset2_eda_report.txt"
)

with open(eda_report, "w", encoding="utf-8") as f:

    f.write("DATASET 2 EDA REPORT\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Dataset Shape: {df.shape}\n\n")

    f.write("Columns:\n")
    f.write(str(df.columns.tolist()))
    f.write("\n\n")

    f.write("Missing Values:\n")
    f.write(str(df.isnull().sum()))
    f.write("\n\n")

    f.write("Descriptive Statistics:\n")
    f.write(str(df.describe()))

print("\nEDA report saved!")

# ============================================================
# COMPLETED
# ============================================================

print("\nEDA COMPLETED SUCCESSFULLY!")
print("=" * 80)