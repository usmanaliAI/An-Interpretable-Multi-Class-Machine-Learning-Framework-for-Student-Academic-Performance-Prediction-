import os

current_dir = os.path.dirname(os.path.abspath(__file__))

print("Current Dir:")
print(current_dir)

print("\nParent 1:")
print(os.path.dirname(current_dir))

print("\nParent 2:")
print(os.path.dirname(os.path.dirname(current_dir)))

print("\nParent 3:")
print(os.path.dirname(os.path.dirname(os.path.dirname(current_dir))))