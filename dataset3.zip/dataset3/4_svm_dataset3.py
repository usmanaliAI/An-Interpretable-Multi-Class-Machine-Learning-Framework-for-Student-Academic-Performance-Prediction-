import pandas as pd
import os

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import (
    train_test_split,
    GridSearchCV
)

from sklearn.preprocessing import StandardScaler

from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

print("=" * 80)
print("MODEL 4 - SUPPORT VECTOR MACHINE (SVM) - DATASET 3")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(current_dir))

data_path = os.path.join(
    project_root,
    "data",
    "StudentPerformanceFactors_dataset3_final.csv"
)

report_path = os.path.join(
    project_root,
    "reports",
    "dataset3",
    "models"
)

table_path = os.path.join(
    project_root,
    "tables",
    "dataset3",
    "models"
)

output_path = os.path.join(
    project_root,
    "outputs",
    "dataset3"
)

figure_path = os.path.join(
    project_root,
    "figures",
    "dataset3",
    "models",
    "svm"
)

os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)
os.makedirs(output_path, exist_ok=True)
os.makedirs(figure_path, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================

print("\nLoading final dataset...")

df = pd.read_csv(data_path)

print("Dataset loaded successfully!")

print("\nDataset Shape:")
print(df.shape)

print("\nSearching for final dataset...")

for root, dirs, files in os.walk(
        os.path.join(project_root, "data")):

    for file in files:

        if file == "StudentPerformanceFactors_dataset3_final.csv":

            data_path = os.path.join(root, file)

            print("\nDataset Found:")
            print(data_path)

            df = pd.read_csv(data_path)

            print("\nDataset loaded successfully!")
            print(df.shape)

            break

# ============================================================
# FEATURES & TARGET
# ============================================================

X = df.drop(
    columns=[
        "Performance_Class",
        "Exam_Score",
        "performance_trend",
        "score_ratio"
    ],
    errors="ignore"
)

y = df["Performance_Class"]

print("\nFeatures Used For Training:")
print(X.columns.tolist())

# ============================================================
# TRAIN TEST SPLIT
# ============================================================

print("\nCreating train/test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("Train Shape:", X_train.shape)
print("Test Shape:", X_test.shape)

# ============================================================
# FEATURE SCALING
# ============================================================

print("\nScaling features...")

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

print("Scaling completed!")

# ============================================================
# GRID SEARCH
# ============================================================

print("\nFinding best SVM parameters...")

param_grid = {
    'C': [0.1, 1, 10],
    'kernel': ['rbf'],
    'gamma': ['scale', 'auto']
}

grid_search = GridSearchCV(
    estimator=SVC(
        class_weight='balanced',
        random_state=42
    ),
    param_grid=param_grid,
    cv=5,
    scoring='accuracy',
    n_jobs=-1
)

grid_search.fit(X_train, y_train)

best_model = grid_search.best_estimator_

print("\nBest Parameters:")
print(grid_search.best_params_)

# ============================================================
# TRAINING COMPLETED
# ============================================================

print("\nTraining completed!")

# ============================================================
# PREDICTIONS
# ============================================================

print("\nMaking predictions...")

y_pred = best_model.predict(X_test)

# ============================================================
# EVALUATION
# ============================================================

accuracy = accuracy_score(y_test, y_pred)

report = classification_report(
    y_test,
    y_pred
)

matrix = confusion_matrix(
    y_test,
    y_pred
)

# ============================================================
# RESULTS
# ============================================================

print("\n" + "=" * 80)
print("SVM RESULTS - DATASET 3")
print("=" * 80)

print("\nAccuracy:")
print(round(accuracy, 4))

print("\nClassification Report:")
print(report)

print("\nConfusion Matrix:")
print(matrix)

# ============================================================
# SAVE METRICS TABLE
# ============================================================

metrics_df = pd.DataFrame({
    "Metric": ["Accuracy"],
    "Value": [accuracy]
})

metrics_df.to_csv(
    os.path.join(
        table_path,
        "dataset3_svm_metrics.csv"
    ),
    index=False
)

# ============================================================
# CONFUSION MATRIX FIGURE
# ============================================================

print("\nCreating confusion matrix figure...")

plt.figure(figsize=(8, 6))

sns.heatmap(
    matrix,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.title(
    "SVM Confusion Matrix - Dataset 3"
)

plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_svm_confusion_matrix.png"
    )
)

plt.close()

print("Confusion matrix figure saved!")

# ============================================================
# ACCURACY FIGURE
# ============================================================

plt.figure(figsize=(5, 5))

plt.bar(
    ["SVM"],
    [accuracy]
)

plt.ylim(0, 1)

plt.title(
    "SVM Accuracy - Dataset 3"
)

plt.ylabel("Accuracy")

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_svm_accuracy.png"
    )
)

plt.close()

print("Accuracy figure saved!")

# ============================================================
# SAVE REPORT
# ============================================================

report_file = os.path.join(
    report_path,
    "dataset3_svm_results.txt"
)

with open(report_file, "w", encoding="utf-8") as f:

    f.write(
        "MODEL 4 - SUPPORT VECTOR MACHINE (SVM)\n"
    )

    f.write("=" * 70 + "\n\n")

    f.write(
        f"Best Parameters: {grid_search.best_params_}\n\n"
    )

    f.write(
        f"Accuracy: {accuracy}\n\n"
    )

    f.write(
        "Classification Report:\n"
    )

    f.write(report)

    f.write(
        "\nConfusion Matrix:\n"
    )

    f.write(str(matrix))

print("\nResults report saved!")
print(report_file)

# ============================================================
# SAVE PREDICTIONS
# ============================================================

prediction_df = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

prediction_df.to_csv(
    os.path.join(
        output_path,
        "dataset3_svm_predictions.csv"
    ),
    index=False
)

print("\nPrediction file saved!")

# ============================================================
# FINAL MESSAGE
# ============================================================

print("\nMODEL COMPLETED SUCCESSFULLY!")
print("=" * 80)