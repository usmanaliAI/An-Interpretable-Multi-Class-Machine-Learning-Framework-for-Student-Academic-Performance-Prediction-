import pandas as pd
import os

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

print("=" * 80)
print("MODEL 2 - RANDOM FOREST - DATASET 3")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================

current_dir = os.path.dirname(os.path.abspath(__file__))

project_root = os.path.dirname(
    os.path.dirname(current_dir)
)
# ------------------------------------------------
# MAIN PATHS
# ------------------------------------------------
data_path = os.path.join(project_root, "data")

report_path = os.path.join(
    project_root,
    "reports",
    "dataset3"
)

table_path = os.path.join(
    project_root,
    "tables",
    "dataset3"
)

output_path = os.path.join(
    project_root,
    "outputs",
    "dataset3"
)

# ------------------------------------------------
# FIGURE PATHS
# ------------------------------------------------
figure_root = os.path.join(project_root, "figures")

dataset3_figure_path = os.path.join(
    figure_root,
    "dataset3"
)

model_figure_path = os.path.join(
    dataset3_figure_path,
    "models"
)

# ------------------------------------------------
# CREATE FOLDERS
# ------------------------------------------------
os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)
os.makedirs(output_path, exist_ok=True)

os.makedirs(figure_root, exist_ok=True)
os.makedirs(dataset3_figure_path, exist_ok=True)
os.makedirs(model_figure_path, exist_ok=True)

# ============================================================
# LOAD DATASET
# ============================================================

# ============================================================
# LOAD DATASET
# ============================================================

print("\nLoading final dataset...")

dataset_file = os.path.join(
    project_root,
    "data",
    "StudentPerformanceFactors_dataset3_final.csv"
)

print("\nDataset File:")
print(dataset_file)

print("\nExists:")
print(os.path.exists(dataset_file))

df = pd.read_csv(dataset_file)

print("Dataset loaded successfully!")

print("\nDataset Shape:")
print(df.shape)

# ============================================================
# REMOVE LEAKAGE FEATURES
# ============================================================

remove_columns = [
    "Performance_Class",
    "Exam_Score",
    "performance_trend",
    "score_ratio"
]

X = df.drop(columns=remove_columns)

y = df["Performance_Class"]

print("\nFeatures Used For Training:")
print(X.columns.tolist())

# ============================================================
# TRAIN TEST SPLIT
# ============================================================

print("\nCreating train/test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("Train Shape:", X_train.shape)
print("Test Shape:", X_test.shape)

# ============================================================
# RANDOM FOREST MODEL
# ============================================================

print("\nCreating Random Forest model...")

model = RandomForestClassifier(
    n_estimators=300,
    criterion='gini',
    max_depth=12,
    min_samples_split=5,
    min_samples_leaf=2,
    class_weight='balanced',
    random_state=42,
    n_jobs=-1
)

# ============================================================
# TRAIN MODEL
# ============================================================

print("\nTraining model...")

model.fit(X_train, y_train)

print("Training completed!")

# ============================================================
# PREDICTIONS
# ============================================================

print("\nMaking predictions...")

y_pred = model.predict(X_test)

# ============================================================
# EVALUATION
# ============================================================

print("\nEvaluating model...")

accuracy = accuracy_score(y_test, y_pred)

report = classification_report(
    y_test,
    y_pred
)

matrix = confusion_matrix(
    y_test,
    y_pred
)

# ============================================================
# RESULTS
# ============================================================

print("\n" + "=" * 80)
print("RANDOM FOREST RESULTS - DATASET 3")
print("=" * 80)

print("\nAccuracy:")
print(round(accuracy, 4))

print("\nClassification Report:")
print(report)

print("\nConfusion Matrix:")
print(matrix)

# ============================================================
# FEATURE IMPORTANCE
# ============================================================

importance_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': model.feature_importances_
})

importance_df = importance_df.sort_values(
    by='Importance',
    ascending=False
)

print("\nTop Feature Importance:")
print(importance_df.head(10))

# ============================================================
# SAVE FEATURE IMPORTANCE TABLE
# ============================================================

importance_df.to_csv(
    os.path.join(
        table_path,
        "dataset3_random_forest_feature_importance.csv"
    ),
    index=False
)

print("\nFeature importance table saved!")

# ============================================================
# CONFUSION MATRIX FIGURE
# ============================================================

print("\nCreating confusion matrix figure...")

plt.figure(figsize=(8, 6))

sns.heatmap(
    matrix,
    annot=True,
    fmt='d',
    cmap='Greens'
)

plt.title(
    "Random Forest Confusion Matrix - Dataset 3",
    fontsize=14
)

plt.xlabel("Predicted Class")
plt.ylabel("Actual Class")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset3_random_forest_confusion_matrix.png"
    )
)

plt.close()

print("Confusion matrix figure saved!")

# ============================================================
# FEATURE IMPORTANCE FIGURE
# ============================================================

print("\nCreating feature importance figure...")

top_features = importance_df.head(10)

plt.figure(figsize=(10, 6))

sns.barplot(
    data=top_features,
    x='Importance',
    y='Feature'
)

plt.title(
    "Top 10 Important Features - Random Forest",
    fontsize=14
)

plt.xlabel("Importance Score")
plt.ylabel("Features")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset3_random_forest_feature_importance.png"
    )
)

plt.close()

print("Feature importance figure saved!")

# ============================================================
# ACCURACY FIGURE
# ============================================================

print("\nCreating accuracy figure...")

plt.figure(figsize=(5, 5))

plt.bar(
    ['Random Forest'],
    [accuracy]
)

plt.ylim(0, 1)

plt.title("Random Forest Accuracy - Dataset 3")

plt.ylabel("Accuracy")

plt.tight_layout()

plt.savefig(
    os.path.join(
        model_figure_path,
        "dataset3_random_forest_accuracy.png"
    )
)

plt.close()

print("Accuracy figure saved!")

# ============================================================
# SAVE RESULTS REPORT
# ============================================================

result_file = os.path.join(
    report_path,
    "dataset3_random_forest_results.txt"
)

with open(result_file, "w", encoding="utf-8") as f:

    f.write("MODEL 2 - RANDOM FOREST - DATASET 3\n")
    f.write("=" * 70 + "\n\n")

    f.write(f"Accuracy: {accuracy}\n\n")

    f.write("Classification Report:\n")
    f.write(report)

    f.write("\nConfusion Matrix:\n")
    f.write(str(matrix))

    f.write("\n\nTop Feature Importance:\n")
    f.write(str(importance_df.head(10)))

print("\nResults report saved!")
print(result_file)

# ============================================================
# SAVE PREDICTIONS
# ============================================================

prediction_df = pd.DataFrame({
    'Actual': y_test,
    'Predicted': y_pred
})

prediction_df.to_csv(
    os.path.join(
        output_path,
        "dataset3_random_forest_predictions.csv"
    ),
    index=False
)

print("\nPrediction file saved!")

# ============================================================
# FINAL MESSAGE
# ============================================================

print("\nMODEL COMPLETED SUCCESSFULLY!")
print("=" * 80)