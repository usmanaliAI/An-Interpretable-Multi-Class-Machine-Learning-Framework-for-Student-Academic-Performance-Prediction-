"""
Dataset A vs Dataset B Machine Learning Comparison

Dataset A:
Original features without feature engineering

Dataset B:
Feature engineered final dataset

Models:
1. Decision Tree
2. Random Forest
3. Logistic Regression
4. SVM
5. XGBoost

Outputs:
- Reports
- Tables
- Figures
- Final comparison CSV
"""

from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix
)


# ==========================================================
# PROJECT PATH
# ==========================================================

# Script location:
# src/dataset3/dataset_comparison/file.py

PROJECT_ROOT = Path(__file__).resolve().parents[3]


DATA_PATH = PROJECT_ROOT / "data"

REPORT_PATH = PROJECT_ROOT / "reports"

TABLE_PATH = PROJECT_ROOT / "tables"

FIGURE_PATH = PROJECT_ROOT / "figures"



print("="*80)
print("DATASET A VS DATASET B MODEL COMPARISON")
print("="*80)

print("\nProject Root:")
print(PROJECT_ROOT)



# ==========================================================
# DATASETS
# ==========================================================

datasets = {

    "StudentPerformanceFactors_datasetA_original_features":

    DATA_PATH /
    "StudentPerformanceFactors_datasetA_original_features.csv",



    "StudentPerformance_datasetB_feature_engineered":

    DATA_PATH /
    "StudentPerformanceFactors_datasetB_feature_engineered.csv"

}



TARGET = "Performance_Class"


RANDOM_STATE = 42



# ==========================================================
# CREATE MAIN DIRECTORIES
# ==========================================================

REPORT_PATH.mkdir(
    parents=True,
    exist_ok=True
)

TABLE_PATH.mkdir(
    parents=True,
    exist_ok=True
)

FIGURE_PATH.mkdir(
    parents=True,
    exist_ok=True
)



# ==========================================================
# MODELS
# ==========================================================

models = {


"Decision Tree":

DecisionTreeClassifier(

    criterion="gini",
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=2,
    class_weight="balanced",
    random_state=42

),



"Random Forest":

RandomForestClassifier(

    n_estimators=300,
    criterion="gini",
    max_depth=12,
    min_samples_split=5,
    min_samples_leaf=2,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1

),



"Logistic Regression":

Pipeline([

    ("scaler",
     StandardScaler()),


    ("model",
     LogisticRegression(

        max_iter=5000,
        class_weight="balanced",
        random_state=42

     ))

]),



"SVM":

Pipeline([

    ("scaler",
     StandardScaler()),


    ("model",
     SVC(

        C=10,
        kernel="rbf",
        gamma="scale",
        class_weight="balanced"

     ))

]),



"XGBoost":

XGBClassifier(

    n_estimators=300,
    max_depth=6,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    eval_metric="mlogloss"

)

}



# ==========================================================
# STORE RESULTS
# ==========================================================

all_results = []



# ==========================================================
# DATASET LOOP
# ==========================================================


for dataset_name, dataset_file in datasets.items():


    print("\n")
    print("="*80)
    print(dataset_name)
    print("="*80)


    print("\nDataset path:")
    print(dataset_file)


    if not dataset_file.exists():

        raise FileNotFoundError(
            f"\nDataset not found:\n{dataset_file}"
        )



    df = pd.read_csv(dataset_file)


    print("\nDataset shape:")
    print(df.shape)



    X = df.drop(
        columns=[TARGET],
        errors="ignore"
    )


    y = df[TARGET]



    print("\nNumber of features:")
    print(X.shape[1])



    X_train, X_test, y_train, y_test = train_test_split(

        X,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y

    )



    # folders

    dataset_report_folder = (
        REPORT_PATH /
        dataset_name
    )


    dataset_table_folder = (
        TABLE_PATH /
        dataset_name
    )


    dataset_figure_folder = (
        FIGURE_PATH /
        dataset_name
    )



    dataset_report_folder.mkdir(
        parents=True,
        exist_ok=True
    )


    dataset_table_folder.mkdir(
        parents=True,
        exist_ok=True
    )


    dataset_figure_folder.mkdir(
        parents=True,
        exist_ok=True
    )



    # ======================================================
    # MODEL TRAINING
    # ======================================================


    for model_name, model in models.items():


        print("\nTraining:")
        print(model_name)



        model.fit(

            X_train,
            y_train

        )



        y_pred = model.predict(
            X_test
        )



        accuracy = accuracy_score(
            y_test,
            y_pred
        )


        precision = precision_score(

            y_test,
            y_pred,
            average="weighted"

        )


        recall = recall_score(

            y_test,
            y_pred,
            average="weighted"

        )


        f1 = f1_score(

            y_test,
            y_pred,
            average="weighted"

        )



        all_results.append({

            "Dataset": dataset_name,

            "Model": model_name,

            "Accuracy": accuracy,

            "Precision": precision,

            "Recall": recall,

            "F1-score": f1

        })



        # -------------------------------
        # SAVE REPORT
        # -------------------------------


        report_file = (

            dataset_report_folder /

            f"{model_name.replace(' ','_')}_results.txt"

        )



        with open(
            report_file,
            "w",
            encoding="utf-8"
        ) as f:


            f.write(
                classification_report(
                    y_test,
                    y_pred
                )
            )

            f.write("\nConfusion Matrix\n")

            f.write(
                str(
                    confusion_matrix(
                        y_test,
                        y_pred
                    )
                )
            )



        # -------------------------------
        # CONFUSION MATRIX FIGURE
        # -------------------------------


        cm = confusion_matrix(
            y_test,
            y_pred
        )


        plt.figure(
            figsize=(6,5)
        )


        sns.heatmap(

            cm,
            annot=True,
            fmt="d"

        )


        plt.title(
            dataset_name +
            " - " +
            model_name
        )


        plt.xlabel(
            "Predicted"
        )


        plt.ylabel(
            "Actual"
        )


        plt.tight_layout()


        plt.savefig(

            dataset_figure_folder /

            f"{model_name.replace(' ','_')}_confusion_matrix.png"

        )


        plt.close()



# ==========================================================
# FINAL COMPARISON TABLE
# ==========================================================


results_df = pd.DataFrame(
    all_results
)



results_file = (

    TABLE_PATH /

    "DatasetA_vs_DatasetB_model_comparison.csv"

)



results_df.to_csv(

    results_file,

    index=False

)



print("\n")
print("="*80)
print("FINAL MODEL COMPARISON")
print("="*80)


print(
    results_df.round(4)
)



print("\nSaved:")
print(results_file)



print("\nPROCESS COMPLETED SUCCESSFULLY")
print("="*80)