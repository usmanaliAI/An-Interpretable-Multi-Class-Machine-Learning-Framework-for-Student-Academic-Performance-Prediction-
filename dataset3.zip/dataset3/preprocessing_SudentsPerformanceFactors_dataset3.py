import pandas as pd
import numpy as np
import os

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder

print("=" * 80)
print("DATASET 3 PREPROCESSING")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
# ------------------------------------------------
# MAIN PATHS
# ------------------------------------------------

data_path = os.path.join(project_root, "data")

report_path = os.path.join(project_root, "reports", "dataset3")

table_path = os.path.join(project_root, "tables", "dataset3")

figure_path = os.path.join(
    project_root,
    "figures",
    "dataset3",
    "preprocessing"
)

# ------------------------------------------------
# CREATE FOLDERS
# ------------------------------------------------

os.makedirs(data_path, exist_ok=True)
os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)
os.makedirs(figure_path, exist_ok=True)

# ============================================================
# LOAD DATASET
# ============================================================

print("\nLoading dataset...")

df = pd.read_csv(
    os.path.join(
        data_path,
        "StudentPerformanceFactors.csv"
    )
)

print("Dataset loaded successfully!")

# ============================================================
# BASIC INFORMATION
# ============================================================

print("\nDataset Shape:")
print(df.shape)

print("\nColumns:")
print(df.columns.tolist())

print("\nData Types:")
print(df.dtypes)

# ============================================================
# DUPLICATE CHECK
# ============================================================

print("\nChecking duplicate rows...")

duplicates = df.duplicated().sum()

print(f"Duplicate Rows: {duplicates}")

df.drop_duplicates(inplace=True)

# ============================================================
# MISSING VALUES
# ============================================================

print("\nChecking missing values...")

missing_values = df.isnull().sum()

print(missing_values)

# ------------------------------------------------
# SAVE MISSING VALUE TABLE
# ------------------------------------------------

missing_table = pd.DataFrame({
    'Column': missing_values.index,
    'Missing_Values': missing_values.values
})

missing_table.to_csv(
    os.path.join(
        table_path,
        "dataset3_missing_values.csv"
    ),
    index=False
)

# ============================================================
# MISSING VALUE FIGURE
# ============================================================

print("\nCreating missing values figure...")

plt.figure(figsize=(12, 6))

sns.heatmap(
    df.isnull(),
    cbar=False
)

plt.title(
    "Dataset 3 Missing Values",
    fontsize=14
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_missing_values_heatmap.png"
    )
)

plt.close()

print("Missing values figure saved!")

# ============================================================
# HANDLE MISSING VALUES
# ============================================================

print("\nHandling missing values...")

numerical_columns = df.select_dtypes(
    include=['int64', 'float64']
).columns.tolist()

categorical_columns = df.select_dtypes(
    include=['object']
).columns.tolist()

# ------------------------------------------------
# NUMERICAL IMPUTATION
# ------------------------------------------------

num_imputer = SimpleImputer(strategy='median')

df[numerical_columns] = num_imputer.fit_transform(
    df[numerical_columns]
)

# ------------------------------------------------
# CATEGORICAL IMPUTATION
# ------------------------------------------------

cat_imputer = SimpleImputer(strategy='most_frequent')

df[categorical_columns] = cat_imputer.fit_transform(
    df[categorical_columns]
)

print("Missing values handled successfully!")

# ============================================================
# ENCODE CATEGORICAL COLUMNS
# ============================================================

print("\nEncoding categorical columns...")

label_encoders = {}

for column in categorical_columns:

    encoder = LabelEncoder()

    df[column] = encoder.fit_transform(df[column])

    label_encoders[column] = encoder

print("Categorical encoding completed!")

# ============================================================
# OUTLIER HANDLING
# ============================================================

print("\nHandling outliers...")

numeric_features = [
    'Hours_Studied',
    'Attendance',
    'Previous_Scores',
    'Sleep_Hours',
    'Exam_Score'
]

for column in numeric_features:

    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)

    IQR = Q3 - Q1

    lower_bound = Q1 - (1.5 * IQR)
    upper_bound = Q3 + (1.5 * IQR)

    df[column] = np.clip(
        df[column],
        lower_bound,
        upper_bound
    )

print("Outliers handled successfully!")

# ============================================================
# DISTRIBUTION FIGURES
# ============================================================

print("\nCreating distribution figures...")

distribution_columns = [
    'Hours_Studied',
    'Attendance',
    'Previous_Scores',
    'Sleep_Hours',
    'Exam_Score'
]

for column in distribution_columns:

    plt.figure(figsize=(7, 5))

    sns.histplot(
        df[column],
        kde=True
    )

    plt.title(
        f"{column} Distribution",
        fontsize=13
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            figure_path,
            f"{column}_distribution.png"
        )
    )

    plt.close()

print("Distribution figures saved!")

# ============================================================
# CORRELATION HEATMAP
# ============================================================

print("\nCreating correlation heatmap...")

plt.figure(figsize=(12, 8))

correlation_matrix = df.corr()

sns.heatmap(
    correlation_matrix,
    cmap='coolwarm'
)

plt.title(
    "Dataset 3 Correlation Heatmap",
    fontsize=14
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_correlation_heatmap.png"
    )
)

plt.close()

print("Correlation heatmap saved!")

# ============================================================
# SAVE CLEANED DATASET
# ============================================================

print("\nSaving cleaned dataset...")

df.to_csv(
    os.path.join(
        data_path,
        "dataset3_cleaned.csv"
    ),
    index=False
)

print("Cleaned dataset saved!")

# ============================================================
# SAVE REPORT
# ============================================================

report_file = os.path.join(
    report_path,
    "dataset3_preprocessing_report.txt"
)

with open(report_file, "w", encoding="utf-8") as f:

    f.write("DATASET 3 PREPROCESSING REPORT\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Dataset Shape: {df.shape}\n\n")

    f.write("Columns:\n")
    f.write(str(df.columns.tolist()))

    f.write("\n\nMissing Values:\n")
    f.write(str(missing_values))

    f.write("\n\nDuplicate Rows Removed:\n")
    f.write(str(duplicates))

print("\nReport Saved:")
print(report_file)

print("\nPREPROCESSING COMPLETED SUCCESSFULLY!")
print("=" * 80)