import pandas as pd
import numpy as np
import os

import matplotlib.pyplot as plt
import seaborn as sns

print("=" * 80)
print("DATASET 3 FEATURE ENGINEERING")
print("=" * 80)

# ============================================================
# PATH SETUP
# ============================================================

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

# ------------------------------------------------
# PATHS
# ------------------------------------------------

data_path = os.path.join(project_root, "data")

report_path = os.path.join(project_root, "reports", "dataset3")

table_path = os.path.join(project_root, "tables", "dataset3")

figure_path = os.path.join(
    project_root,
    "figures",
    "dataset3",
    "feature_engineering"
)

# ------------------------------------------------
# CREATE FOLDERS
# ------------------------------------------------

os.makedirs(report_path, exist_ok=True)
os.makedirs(table_path, exist_ok=True)
os.makedirs(figure_path, exist_ok=True)

# ============================================================
# LOAD CLEANED DATASET
# ============================================================

print("\nLoading cleaned dataset...")

df = pd.read_csv(
    os.path.join(
        data_path,
        "dataset3_cleaned.csv"
    )
)

print("Dataset loaded successfully!")

# ============================================================
# FEATURE ENGINEERING
# ============================================================

print("\nCreating engineered features...")

# ------------------------------------------------
# STUDY EFFICIENCY
# ------------------------------------------------

df["study_efficiency"] = (
    df["Hours_Studied"] /
    df["Sleep_Hours"]
)

df["study_efficiency"] = df[
    "study_efficiency"
].replace(
    [np.inf, -np.inf],
    np.nan
).fillna(0)

# ------------------------------------------------
# ATTENDANCE SCORE
# ------------------------------------------------

df["attendance_score"] = (
    df["Attendance"] / 100
)

# ------------------------------------------------
# PERFORMANCE TREND
# ------------------------------------------------

df["performance_trend"] = (
    df["Exam_Score"] -
    df["Previous_Scores"]
)

# ------------------------------------------------
# SLEEP QUALITY
# ------------------------------------------------

df["sleep_quality"] = (
    df["Sleep_Hours"] / 8
)

# ------------------------------------------------
# SCORE RATIO
# ------------------------------------------------

df["score_ratio"] = (
    df["Exam_Score"] /
    df["Previous_Scores"]
)

df["score_ratio"] = df[
    "score_ratio"
].replace(
    [np.inf, -np.inf],
    np.nan
).fillna(1)

# ------------------------------------------------
# OVERALL PRODUCTIVITY
# ------------------------------------------------

df["overall_productivity"] = (
    df["Hours_Studied"] *
    df["attendance_score"]
)

print("Feature engineering completed!")

# ============================================================
# TARGET CREATION
# ============================================================

print("\nCreating target class...")

def score_to_class(score):

    # LOW PERFORMANCE
    if score < 60:
        return 0

    # MEDIUM PERFORMANCE
    elif score < 75:
        return 1

    # HIGH PERFORMANCE
    else:
        return 2

df["Performance_Class"] = df[
    "Exam_Score"
].apply(score_to_class)

print("Target class created successfully!")

# ============================================================
# TARGET DISTRIBUTION
# ============================================================

print("\nTarget Distribution:")
print(df["Performance_Class"].value_counts())

# ============================================================
# FEATURE SUMMARY TABLE
# ============================================================

feature_summary = pd.DataFrame({
    "Feature": df.columns,
    "Data_Type": df.dtypes.values
})

feature_summary.to_csv(
    os.path.join(
        table_path,
        "dataset3_feature_summary.csv"
    ),
    index=False
)

print("\nFeature summary table saved!")

# ============================================================
# TARGET DISTRIBUTION FIGURE
# ============================================================

print("\nCreating target distribution figure...")

plt.figure(figsize=(7, 5))

sns.countplot(
    x=df["Performance_Class"]
)

plt.title(
    "Performance Class Distribution",
    fontsize=13
)

plt.xlabel(
    "Class (0=Low, 1=Medium, 2=High)"
)

plt.ylabel("Count")

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_target_distribution.png"
    )
)

plt.close()

print("Target distribution figure saved!")

# ============================================================
# CORRELATION HEATMAP
# ============================================================

print("\nCreating updated correlation heatmap...")

plt.figure(figsize=(14, 10))

sns.heatmap(
    df.corr(),
    cmap="coolwarm"
)

plt.title(
    "Dataset 3 Correlation Heatmap After Feature Engineering",
    fontsize=14
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        figure_path,
        "dataset3_feature_correlation_heatmap.png"
    )
)

plt.close()

print("Correlation heatmap saved!")

# ============================================================
# SAVE FINAL DATASET
# ============================================================

print("\nSaving final dataset...")

df.to_csv(
    os.path.join(
        data_path,
        "dataset3_final.csv"
    ),
    index=False
)

print("Final dataset saved!")

# ============================================================
# SAVE REPORT
# ============================================================

report_file = os.path.join(
    report_path,
    "dataset3_feature_engineering_report.txt"
)

with open(report_file, "w", encoding="utf-8") as f:

    f.write("DATASET 3 FEATURE ENGINEERING REPORT\n")
    f.write("=" * 60 + "\n\n")

    f.write(f"Final Dataset Shape: {df.shape}\n\n")

    f.write("Features:\n")
    f.write(str(df.columns.tolist()))

    f.write("\n\nTarget Distribution:\n")
    f.write(
        str(
            df["Performance_Class"].value_counts()
        )
    )

print("\nReport Saved:")
print(report_file)

# ============================================================
# FINAL MESSAGE
# ============================================================

print("\nFEATURE ENGINEERING COMPLETED SUCCESSFULLY!")
print("=" * 80)