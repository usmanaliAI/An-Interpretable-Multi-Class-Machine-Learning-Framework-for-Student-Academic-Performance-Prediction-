import pandas as pd
import os

# Project root
project_root = r"D:\nndl2024\Usman_YLU_final_project"

dataset_path = os.path.join(
    project_root,
    "data",
    "StudentPerformanceFactors_dataset3_final.csv"
)

print("Dataset path:")
print(dataset_path)

df = pd.read_csv(dataset_path)

remove_columns = [
    "Performance_Class",
    "Exam_Score",
    "performance_trend",
    "score_ratio"
]

X = df.drop(
    columns=remove_columns,
    errors="ignore"
)

print("\nNumber of modelling features:")
print(X.shape[1])

print("\nFeatures used for modelling:")

for i, col in enumerate(X.columns, 1):
    print(i, col)