import pandas as pd
import os


print("=" * 80)
print("CREATING DATASET A AND DATASET B FOR FEATURE ENGINEERING COMPARISON")
print("=" * 80)


# ============================================================
# PROJECT PATH
# ============================================================

project_root = os.path.dirname(
    os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
)


data_folder = os.path.join(
    project_root,
    "data"
)


# ============================================================
# LOAD FINAL DATASET
# ============================================================

input_file = os.path.join(
    data_folder,
    "StudentPerformanceFactors_dataset3_final.csv"
)


print("\nLoading dataset:")
print(input_file)


df = pd.read_csv(input_file)


print("\nOriginal Dataset Shape:")
print(df.shape)


# ============================================================
# ENGINEERED FEATURES
# ============================================================

engineered_features = [

    "study_efficiency",
    "attendance_score",
    "sleep_quality",
    "overall_productivity"

]


# ============================================================
# DATASET A
# WITHOUT FEATURE ENGINEERING
# ============================================================

dataset_A = df.drop(
    columns=engineered_features,
    errors="ignore"
)


dataset_A_path = os.path.join(
    data_folder,
    "StudentPerformanceFactors_datasetA_original_features.csv"
)


dataset_A.to_csv(
    dataset_A_path,
    index=False
)


print("\nDataset A created:")
print(dataset_A_path)

print("Dataset A shape:")
print(dataset_A.shape)



# ============================================================
# DATASET B
# WITH FEATURE ENGINEERING
# ============================================================

dataset_B = df.copy()


dataset_B_path = os.path.join(
    data_folder,
    "StudentPerformanceFactors_datasetB_feature_engineered.csv"
)


dataset_B.to_csv(
    dataset_B_path,
    index=False
)


print("\nDataset B created:")
print(dataset_B_path)

print("Dataset B shape:")
print(dataset_B.shape)



# ============================================================
# FEATURE COMPARISON
# ============================================================

print("\nFeature Comparison")
print("=" * 50)

print(
    "Dataset A features:",
    dataset_A.shape[1]
)

print(
    "Dataset B features:",
    dataset_B.shape[1]
)


print("\nEngineered features added:")

for feature in engineered_features:
    print("-", feature)


print("\nDATASET CREATION COMPLETED SUCCESSFULLY")
print("=" * 80)